import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react"
import {
  ArrowClockwise,
  Bug,
  ChatCenteredDots,
  Cpu,
  Fish,
  GameController,
  Lightning,
  Moon,
  Plug,
  Power,
  SpinnerGap,
  StopCircle,
  TerminalWindow,
  TShirt,
} from "@phosphor-icons/react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { MinimapPanel } from "@/components/minimap"
import { TileSprite } from "@/components/TileSprite"
import {
  automateTutorial,
  connectWithAuth,
  terminateSession,
  dropItem,
  getAuthToken,
  getDashboardAuthStatus,
  getLuaScriptStatus,
  loadBlockTypes,
  getMinimap,
  joinWorld,
  leaveWorld,
  listSessions,
  loginDashboard,
  logoutDashboard,
  moveSession,
  reconnectSession,
  registerDashboardPassword,
  setAuthToken,
  startAutomine,
  startFishing,
  startLuaScript,
  startSpam,
  stopAutomine,
  stopFishing,
  stopLuaScript,
  stopSpam,
  talk,
  wearItem,
  type ActionResponse,
} from "@/lib/api"
import {
  buildWebSocketUrl,
  camelToWords,
  generateDeviceId,
  getItemCategory,
  inventoryTypeLabel,
  sortSessions,
  statusVariant,
} from "@/lib/dashboard"
import type {
  AuthInput,
  AuthKind,
  DashboardAuthStatus,
  LogEvent,
  LuaScriptStatusSnapshot,
  MinimapSnapshot,
  ServerEvent,
  SessionSnapshot,
  BlockNameMap,
} from "@/lib/types"

type Feedback = { kind: "success" | "error"; message: string }

function sessionDisplayName(session: SessionSnapshot) {
  const name = session.username?.trim()
  if (name) return name
  const shortDevice = session.device_id ? session.device_id.slice(-6).toUpperCase() : session.id
  return `Bot ${shortDevice}`
}


type SessionInputs = {
  world: string
  bait: string
  chat: string
  luaSource: string
  spam: string
  spamDelay: string
}

const EMPTY_INPUTS: SessionInputs = {
  world: "",
  bait: "",
  chat: "",
  luaSource: "",
  spam: "",
  spamDelay: "5",
}

const CLOTHING_TYPES = new Set([768, 1024])

const runningStatuses = new Set(["connecting", "authenticating", "joining_world", "loading_world", "awaiting_ready", "in_world", "redirecting"])

const LUA_TEMPLATE_SCRIPTS = {
  quickStatus: `-- Quick status untuk session aktif\nlog("Rawa Rontek Lua Executor")\nlog("scope:", EXECUTION_SCOPE or "single-session")\n\nlocal p = bot:pos()\nlog("world:", bot:get_world_name() or "-")\nlog("state:", bot:state())\nlog("pos:", p.tile_x or p.x or "-", p.tile_y or p.y or "-")\n\nlocal inv = bot:inventory()\nif inv then\n  log("inventory:", inv.used or 0, "/", inv.size or 0, "free:", inv.free or 0)\nend`,
  worldFlow: `-- Flow world normal: join -> tunggu world loaded -> cek posisi\nlocal target = "PIXELSTATION"\nlog("joining", target)\nbot:join_world(target)\n\nlocal deadline = now_ms() + 30000\nwhile now_ms() < deadline do\n  if bot:get_world_name() == target then\n    local w = bot:get_world()\n    if w and (w.width or 0) > 0 then\n      local p = bot:pos()\n      log("entered", target, "at", p.tile_x or p.x, p.tile_y or p.y)\n      return\n    end\n  end\n  sleep(500)\nend\n\nlog("timeout waiting for world")`,
  passiveCollect: `-- Passive pickup: jalan ke tile item, tunggu auto-pickup\nlocal function distance(a, b)\n  return math.abs((a.tile_x or a.x) - b.x) + math.abs((a.tile_y or a.y) - b.y)\nend\n\nlocal list = bot:get_collectables()\nif #list == 0 then\n  log("no collectables")\n  return\nend\n\ntable.sort(list, function(a, b) return distance(bot:pos(), a) < distance(bot:pos(), b) end)\nlocal item = list[1]\nlog("walking to item", item.id, "block", item.block_type, "at", item.x, item.y)\nbot:find_path(item.x, item.y)\nsleep(900)\nlog("pickup wait done")`,
  inventoryReport: `-- Inventory report\nlocal inv = bot:get_inventory()\nlog("items:", #inv)\nfor _, item in ipairs(inv) do\n  log("#" .. tostring(item.id), "x" .. tostring(item.amount), item.name or "")\nend\n\nlocal acc = bot:get_account()\nif acc then\n  log("gems:", acc.gems, "level:", acc.level, "slots:", acc.inventory_slots)\nend`,
  eventWatch: `-- Event watcher: biarkan script hidup supaya listener tetap aktif\nbot:on(events.STATE_CHANGED, function(data)\n  log("state changed:", data.state)\nend)\n\nbot:on(events.JOINED_WORLD, function(data)\n  log("joined world:", data.world)\nend)\n\nwhile true do\n  sleep(1000)\nend`,
} as const

const LUA_API_GROUPS = [
  { title: "Runtime", items: ["log(...)", "print(...)", "sleep(ms)", "sleep_ms(ms)", "now_ms()", "EXECUTION_SCOPE", "SLOT_ID"] },
  { title: "Bot Session", items: ["bot:name()", "bot:state()", "bot:connected()", "bot:connect()", "bot:disconnect()", "bot:get_ping()"] },
  { title: "World", items: ["bot:warp(world)", "bot:join_world(world)", "bot:get_world_name()", "bot:get_world()", "bot:leave()", "bot:respawn()"] },
  { title: "Movement", items: ["bot:pos()", "bot:walk(dx,dy)", "bot:find_path(x,y)", "bot:walkTo(x,y)", "bot:start_path(x,y)", "bot:isWalkable(x,y)"] },
  { title: "Blocks & Items", items: ["bot:hit_block(dx,dy)", "bot:hit_block_at(x,y)", "bot:place_block(dx,dy,id)", "bot:place(x,y,id)", "bot:equip(id)", "bot:drop(id, amount)"] },
  { title: "Inventory", items: ["bot:inventory()", "bot:get_inventory()", "bot:has_item(id,min)", "bot:get_account()", "getItemInfo(id)", "getItemInfos()"] },
  { title: "Collectables", items: ["bot:get_collectables()", "bot:collect(id)", "bot:collectAll()"] },
  { title: "Events", items: ["bot:on(event, cb)", "bot:once(event, cb)", "bot:off(event)", "events.JOINED_WORLD", "events.ERROR", "events.TUTORIAL_COMPLETED"] },
]


function App() {
  const [authKind, setAuthKind] = useState<AuthKind>("android_device")
  const [deviceId, setDeviceId] = useState("")
  const [jwt, setJwt] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [dashboardPassword, setDashboardPassword] = useState("")
  const [dashboardStatus, setDashboardStatus] = useState<DashboardAuthStatus | null>(null)
  const [dashboardToken, setDashboardToken] = useState<string | null>(getAuthToken())
  const [dashboardBusy, setDashboardBusy] = useState(false)
  const [connecting, setConnecting] = useState(false)
  const [bulkCount, setBulkCount] = useState("3")
  const [mineLevel, setMineLevel] = useState("1")
  const [mineSpeed, setMineSpeed] = useState("300")
  const [moveSpeed, setMoveSpeed] = useState("110")
  const [breakSpeed, setBreakSpeed] = useState("180")
  const [breakGemBlocks, setBreakGemBlocks] = useState(true)
  const [killMonsters, setKillMonsters] = useState(true)
  const [collectCollectables, setCollectCollectables] = useState(true)
  const [autoUpgradeInventory, setAutoUpgradeInventory] = useState(true)
  const [sessions, setSessions] = useState<SessionSnapshot[]>([])
  const [activeSessionId, setActiveSessionId] = useState("")
  const [sessionInputs, setSessionInputs] = useState<Record<string, SessionInputs>>({})
  const [minimaps, setMinimaps] = useState<Record<string, MinimapSnapshot | null>>({})
  const [luaStatuses, setLuaStatuses] = useState<Record<string, LuaScriptStatusSnapshot | null>>({})
  const [logs, setLogs] = useState<LogEvent[]>([])
  const [logScopeFilter, setLogScopeFilter] = useState("all")
  const [feedback, setFeedback] = useState<Feedback | null>(null)
  const [blockNames, setBlockNames] = useState<BlockNameMap>({})
  const [dropAmounts, setDropAmounts] = useState<Record<string, string>>({})
  const reconnectTimerRef = useRef<number | null>(null)
  const terminatedSessionsRef = useRef<Set<string>>(new Set())

  const dashboardAuthenticated = dashboardStatus?.authenticated ?? false
  const activeSession = sessions.find((session) => session.id === activeSessionId) ?? sessions[0]

  const stats = useMemo(() => {
    const running = sessions.filter((session) => runningStatuses.has(session.status)).length
    const inWorld = sessions.filter((session) => session.status === "in_world").length
    const error = sessions.filter((session) => session.status === "error" || session.last_error).length
    const luaRunning = Object.values(luaStatuses).filter((status) => status?.running).length
    return { total: sessions.length, running, inWorld, error, luaRunning }
  }, [luaStatuses, sessions])

  const refreshDashboardStatus = useCallback(async () => {
    try {
      const status = await getDashboardAuthStatus()
      setDashboardStatus(status)
      if (!status.authenticated) {
        setDashboardToken(null)
        setAuthToken(null)
      }
    } catch (error) {
      setFeedback({ kind: "error", message: error instanceof Error ? error.message : "dashboard auth failed" })
    }
  }, [])

  const upsertSession = useCallback((snapshot: SessionSnapshot) => {
    if (terminatedSessionsRef.current.has(snapshot.id)) return
    setSessions((current) => {
      const next = [...current]
      const index = next.findIndex((session) => session.id === snapshot.id)
      if (index >= 0) next[index] = snapshot
      else next.push(snapshot)
      return sortSessions(next)
    })
  }, [])

  const removeSessionLocal = useCallback((sessionId: string) => {
    terminatedSessionsRef.current.add(sessionId)
    setSessions((current) => current.filter((session) => session.id !== sessionId))
    setSessionInputs((current) => {
      const next = { ...current }
      delete next[sessionId]
      return next
    })
    setLuaStatuses((current) => {
      const next = { ...current }
      delete next[sessionId]
      return next
    })
    setMinimaps((current) => {
      const next = { ...current }
      delete next[sessionId]
      return next
    })
  }, [])

  const updateFromAction = useCallback((response: ActionResponse) => {
    if (response.session) upsertSession(response.session)
    if (response.result?.message || response.message) {
      setFeedback({ kind: "success", message: response.result?.message ?? response.message ?? "OK" })
    }
  }, [upsertSession])

  const terminateSessionAndRemove = useCallback(async (sessionId: string) => {
    const response = await terminateSession(sessionId)
    removeSessionLocal(sessionId)
    const payload = await listSessions()
    setSessions(sortSessions(payload.sessions ?? []))
    return response
  }, [removeSessionLocal])

  useEffect(() => { void refreshDashboardStatus() }, [refreshDashboardStatus])

  useEffect(() => { void loadBlockTypes().then(setBlockNames).catch(() => setBlockNames({})) }, [])

  useEffect(() => {
    if (!dashboardAuthenticated) return
    void listSessions()
      .then((sessionPayload) => {
        setSessions(sortSessions(sessionPayload.sessions ?? []))
      })
      .catch((error: Error) => setFeedback({ kind: "error", message: error.message }))
  }, [dashboardAuthenticated])

  useEffect(() => {
    setSessionInputs((current) => {
      const next = { ...current }
      for (const session of sessions) {
        if (!next[session.id]) next[session.id] = { ...EMPTY_INPUTS, world: session.current_world ?? "" }
        else if (!next[session.id].world && session.current_world) next[session.id] = { ...next[session.id], world: session.current_world }
      }
      return next
    })
    setActiveSessionId((current) => current && sessions.some((session) => session.id === current) ? current : sessions[0]?.id ?? "")
  }, [sessions])

  useEffect(() => {
    if (!dashboardAuthenticated) return
    let cancelled = false
    let socket: WebSocket | null = null
    let reconnectDelay = 1000

    const connect = () => {
      if (cancelled) return
      socket = new WebSocket(buildWebSocketUrl(dashboardToken))
      socket.onopen = () => {
        reconnectDelay = 1000
        setFeedback((current) => current?.message === "dashboard websocket disconnected" ? null : current)
      }
      socket.onmessage = (event) => {
        const payload = JSON.parse(event.data) as ServerEvent
        if (payload.type === "log") {
          setLogs((current) => [...current.slice(-799), payload.event])
          return
        }
        if (payload.type === "session") {
          if (terminatedSessionsRef.current.has(payload.snapshot.id)) return
          upsertSession(payload.snapshot)
          return
        }
        setFeedback({ kind: "success", message: payload.event.message })
      }
      socket.onclose = () => {
        if (cancelled) return
        setFeedback({ kind: "error", message: "dashboard websocket disconnected" })
        reconnectTimerRef.current = window.setTimeout(() => {
          reconnectDelay = Math.min(reconnectDelay * 2, 5000)
          connect()
        }, reconnectDelay)
      }
    }

    connect()
    return () => {
      cancelled = true
      if (reconnectTimerRef.current !== null) window.clearTimeout(reconnectTimerRef.current)
      socket?.close()
    }
  }, [dashboardAuthenticated, dashboardToken, upsertSession])

  const refreshMinimap = useCallback(async (sessionId: string) => {
    try {
      const payload = await getMinimap(sessionId)
      setMinimaps((current) => ({ ...current, [sessionId]: payload.minimap ?? null }))
    } catch {
      setMinimaps((current) => ({ ...current, [sessionId]: null }))
    }
  }, [])

  const refreshLuaStatus = useCallback(async (sessionId: string) => {
    try {
      const payload = await getLuaScriptStatus(sessionId)
      setLuaStatuses((current) => ({ ...current, [sessionId]: payload.status ?? null }))
    } catch {
      setLuaStatuses((current) => ({ ...current, [sessionId]: null }))
    }
  }, [])

  useEffect(() => {
    sessions.forEach((session) => {
      if (session.status === "in_world" || session.status === "loading_world" || session.status === "awaiting_ready") void refreshMinimap(session.id)
      void refreshLuaStatus(session.id)
    })
  }, [refreshLuaStatus, refreshMinimap, sessions])

  const runAction = useCallback(async (action: () => Promise<ActionResponse>) => {
    try {
      updateFromAction(await action())
    } catch (error) {
      if (error instanceof Error && error.message.toLowerCase().includes("unauthorized")) await refreshDashboardStatus()
      setFeedback({ kind: "error", message: error instanceof Error ? error.message : "request failed" })
    }
  }, [refreshDashboardStatus, updateFromAction])

  const createAuthInput = useMemo<AuthInput>(() => {
    if (authKind === "jwt") return { kind: "jwt", jwt, device_id: deviceId || null }
    if (authKind === "email_password") return { kind: "email_password", email, password, device_id: deviceId || null }
    return { kind: "android_device", device_id: deviceId || null }
  }, [authKind, deviceId, email, jwt, password])

  const handleConnect = async () => {
    setConnecting(true)
    try { updateFromAction(await connectWithAuth(createAuthInput)) }
    catch (error) { setFeedback({ kind: "error", message: error instanceof Error ? error.message : "connect failed" }) }
    finally { setConnecting(false) }
  }

  const handleBulkConnect = async () => {
    const total = Math.max(1, Math.min(50, Number.parseInt(bulkCount, 10) || 1))
    setConnecting(true)
    try {
      let created = 0
      for (let index = 0; index < total; index += 1) {
        const bulkDeviceId = generateDeviceId()
        const auth: AuthInput = authKind === "jwt"
          ? { kind: "jwt", jwt, device_id: deviceId || bulkDeviceId }
          : authKind === "email_password"
            ? { kind: "email_password", email, password, device_id: deviceId || bulkDeviceId }
            : { kind: "android_device", device_id: bulkDeviceId }
        const response = await connectWithAuth(auth)
        updateFromAction(response)
        created += 1
      }
      setFeedback({ kind: "success", message: `${created} bulk session berhasil dibuat` })
      const payload = await listSessions()
      setSessions(sortSessions(payload.sessions ?? []))
    } catch (error) {
      setFeedback({ kind: "error", message: error instanceof Error ? error.message : "bulk connect failed" })
    } finally { setConnecting(false) }
  }

  const handleDashboardAuth = async () => {
    const registered = dashboardStatus?.registered ?? false
    setDashboardBusy(true)
    try {
      const response = registered ? await loginDashboard(dashboardPassword) : await registerDashboardPassword(dashboardPassword)
      if (response.token) {
        setAuthToken(response.token)
        setDashboardToken(response.token)
      }
      setDashboardPassword("")
      await refreshDashboardStatus()
      if (response.message) setFeedback({ kind: "success", message: response.message })
    } catch (error) {
      setFeedback({ kind: "error", message: error instanceof Error ? error.message : "auth failed" })
    } finally { setDashboardBusy(false) }
  }

  const handleDashboardLogout = async () => {
    setDashboardBusy(true)
    try { await logoutDashboard() } catch { /* ignore */ }
    finally {
      setAuthToken(null)
      setDashboardToken(null)
      await refreshDashboardStatus()
      setDashboardBusy(false)
    }
  }

  const mutateSessionInput = (sessionId: string, field: keyof SessionInputs, value: string) => {
    setSessionInputs((current) => ({ ...current, [sessionId]: { ...(current[sessionId] ?? EMPTY_INPUTS), [field]: value } }))
  }

  const loadLuaTemplate = (sessionId: string, template: keyof typeof LUA_TEMPLATE_SCRIPTS) => {
    mutateSessionInput(sessionId, "luaSource", LUA_TEMPLATE_SCRIPTS[template])
    setFeedback({ kind: "success", message: "Template Lua dimuat ke editor." })
  }

  const parseSpamDelayMs = (rawValue: string) => {
    const seconds = Number(rawValue)
    if (!Number.isFinite(seconds) || seconds <= 0) throw new Error("delay harus angka lebih dari 0 detik")
    return Math.max(250, Math.round(seconds * 1000))
  }

  const selectedMineLevel = () => {
    const level = Number(mineLevel)
    if (!Number.isFinite(level)) return 1
    return Math.min(5, Math.max(1, Math.trunc(level)))
  }

  const selectedMineSpeed = () => {
    const speed = Number(mineSpeed)
    if (!Number.isFinite(speed)) return 300
    return Math.min(1000, Math.max(180, Math.trunc(speed)))
  }

  const selectedMoveSpeed = () => {
    const speed = Number(moveSpeed)
    if (!Number.isFinite(speed)) return 110
    return Math.min(500, Math.max(55, Math.trunc(speed)))
  }

  const selectedBreakSpeed = () => {
    const speed = Number(breakSpeed)
    if (!Number.isFinite(speed)) return 180
    return Math.min(700, Math.max(80, Math.trunc(speed)))
  }

  const automineOptions = () => ({
    level: selectedMineLevel(),
    speed_ms: selectedMineSpeed(),
    move_delay_ms: selectedMoveSpeed(),
    break_delay_ms: selectedBreakSpeed(),
    break_gem_blocks: breakGemBlocks,
    kill_monsters: killMonsters,
    collect_collectables: collectCollectables,
    auto_upgrade_inventory: autoUpgradeInventory,
  })

  const runAll = (action: (session: SessionSnapshot) => Promise<ActionResponse>) => {
    sessions.forEach((session) => void runAction(() => action(session)))
  }

  const runnableBotSessions = () => sessions.filter((session) => session.status !== "disconnected" && session.status !== "error")

  const runTutorialAllSessions = async () => {
    const targets = runnableBotSessions()
    if (!targets.length) {
      setFeedback({ kind: "error", message: "Belum ada session aktif untuk menjalankan tutorial." })
      return
    }
    setFeedback({ kind: "success", message: `Menjalankan tutorial untuk ${targets.length} session...` })
    for (const session of targets) {
      setActiveSessionId(session.id)
      try {
        updateFromAction(await automateTutorial(session.id))
        await new Promise((resolve) => window.setTimeout(resolve, 350))
      } catch (error) {
        setFeedback({ kind: "error", message: `${sessionDisplayName(session)}: ${error instanceof Error ? error.message : "tutorial failed"}` })
      }
    }
    const payload = await listSessions()
    setSessions(sortSessions(payload.sessions ?? []))
  }

  const runAutomineAllSessions = async () => {
    const targets = runnableBotSessions()
    if (!targets.length) {
      setFeedback({ kind: "error", message: "Belum ada session aktif untuk menjalankan automine." })
      return
    }
    setFeedback({ kind: "success", message: `Menjalankan automine level ${selectedMineLevel()} untuk ${targets.length} session...` })
    for (const session of targets) {
      setActiveSessionId(session.id)
      try {
        updateFromAction(await startAutomine(session.id, automineOptions()))
        await new Promise((resolve) => window.setTimeout(resolve, 250))
      } catch (error) {
        setFeedback({ kind: "error", message: `${sessionDisplayName(session)}: ${error instanceof Error ? error.message : "automine failed"}` })
      }
    }
    const payload = await listSessions()
    setSessions(sortSessions(payload.sessions ?? []))
  }

  const stopAutomineAllSessions = async () => {
    const targets = runnableBotSessions()
    if (!targets.length) {
      setFeedback({ kind: "error", message: "Belum ada session aktif untuk stop automine." })
      return
    }
    setFeedback({ kind: "success", message: `Stop automine untuk ${targets.length} session...` })
    for (const session of targets) {
      setActiveSessionId(session.id)
      try {
        updateFromAction(await stopAutomine(session.id))
        await new Promise((resolve) => window.setTimeout(resolve, 150))
      } catch (error) {
        setFeedback({ kind: "error", message: `${sessionDisplayName(session)}: ${error instanceof Error ? error.message : "stop automine failed"}` })
      }
    }
    const payload = await listSessions()
    setSessions(sortSessions(payload.sessions ?? []))
  }

  const formatLogTime = (timestampMs: number) => new Date(timestampMs).toLocaleTimeString([], { hour12: false })

  const filteredLogs = logs.filter((log) => {
    if (logScopeFilter === "all") return true
    if (logScopeFilter === "error") return log.level === "error"
    if (logScopeFilter === "active") return log.session_id === activeSessionId
    return log.scope === logScopeFilter
  })

  if (!dashboardStatus || !dashboardAuthenticated) {
    const registered = dashboardStatus?.registered ?? false
    return (
      <div className="min-h-screen overflow-hidden bg-[radial-gradient(circle_at_top,rgba(34,211,238,.20),transparent_35%),linear-gradient(135deg,#020617,#0f172a_60%,#111827)] text-foreground">
        <div className="mx-auto flex min-h-screen max-w-xl items-center px-4 py-10">
          <Card className="glass-dark w-full rounded-3xl border-white/10 shadow-2xl">
            <CardHeader className="space-y-2">
              <CardTitle className="flex items-center gap-2 text-2xl"><Moon className="size-6 text-primary" /> Rawa Rontek Dashboard</CardTitle>
              <CardDescription>{registered ? "Masukkan password dashboard." : "Buat password dashboard dulu."}</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <Input type="password" value={dashboardPassword} onChange={(event) => setDashboardPassword(event.target.value)} placeholder="Password" className="h-11 rounded-2xl border-white/10 bg-white/5" />
              <Button onClick={() => void handleDashboardAuth()} disabled={dashboardBusy || !dashboardPassword} className="h-11 rounded-2xl">
                {dashboardBusy ? <SpinnerGap className="size-4 animate-spin" /> : <Plug className="size-4" />}
                {registered ? "Unlock" : "Create Password"}
              </Button>
              {feedback ? <div className={`rounded-2xl border px-3 py-2 text-xs ${feedback.kind === "error" ? "border-red-500/30 bg-red-500/10 text-red-100" : "border-emerald-500/30 bg-emerald-500/10 text-emerald-100"}`}>{feedback.message}</div> : null}
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const inputs = activeSession ? (sessionInputs[activeSession.id] ?? EMPTY_INPUTS) : EMPTY_INPUTS
  const activeLogs = logs.filter((log) => log.session_id === activeSession?.id).slice(-80)

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_10%_0%,rgba(56,189,248,.20),transparent_30%),radial-gradient(circle_at_80%_10%,rgba(99,102,241,.18),transparent_28%),linear-gradient(135deg,#020617,#0f172a_55%,#111827)] text-foreground selection:bg-primary/30">
      <div className="mx-auto grid max-w-[1840px] gap-5 px-4 py-5 xl:grid-cols-[360px_1fr]">
        <aside className="grid gap-4 xl:sticky xl:top-5 xl:self-start">
          <Card className="glass overflow-hidden rounded-3xl border-white/10 shadow-2xl">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="flex items-center gap-2 text-2xl"><Moon className="size-6 text-primary" /> Rawa Rontek</CardTitle>
                <Badge className="rounded-full bg-emerald-500/15 text-emerald-200">Live</Badge>
              </div>
              <CardDescription>Rawa Rontek control center dengan layout premium, session manager, dan debug realtime.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3">
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <div className="text-xs font-semibold text-slate-200">Global Automine</div>
                <div className="mt-1 text-[11px] text-muted-foreground">Lv.{selectedMineLevel()} · Move {selectedMoveSpeed()}ms · Break {selectedBreakSpeed()}ms</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Stat label="Total" value={stats.total} />
                <Stat label="Running" value={stats.running} />
                <Stat label="In world" value={stats.inWorld} />
                <Stat label="Lua" value={stats.luaRunning} />
              </div>
              {stats.error ? <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-100">{stats.error} session punya error. Cek console/session log.</div> : null}
              <Select value={authKind} onValueChange={(value) => setAuthKind(value as AuthKind)}>
                <SelectTrigger className="rounded-2xl border-white/10 bg-white/5"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="android_device">Android Device</SelectItem><SelectItem value="jwt">JWT</SelectItem><SelectItem value="email_password">Email + Password</SelectItem></SelectContent>
              </Select>
              <div className="grid gap-2 sm:grid-cols-[1fr_auto] xl:grid-cols-[1fr_auto]">
                <Input value={deviceId} onChange={(event) => setDeviceId(event.target.value)} placeholder="Device ID" className="rounded-2xl border-white/10 bg-white/5" />
                <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => setDeviceId(generateDeviceId())}>Generate</Button>
              </div>
              {authKind === "jwt" ? <Textarea value={jwt} onChange={(event) => setJwt(event.target.value)} rows={5} placeholder="JWT token" className="rounded-2xl border-white/10 bg-white/5" /> : null}
              {authKind === "email_password" ? <div className="grid gap-2"><Input value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Email" className="rounded-2xl border-white/10 bg-white/5" /><Input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Password" className="rounded-2xl border-white/10 bg-white/5" /></div> : null}
              <div className="grid grid-cols-2 gap-2">
                <Button onClick={() => void handleConnect()} disabled={connecting} className="rounded-2xl">{connecting ? <SpinnerGap className="size-4 animate-spin" /> : <Plug className="size-4" />}Connect</Button>
                <Button variant="outline" onClick={() => void handleDashboardLogout()} disabled={dashboardBusy} className="rounded-2xl border-white/10 bg-white/5"><Power className="size-4" />Lock</Button>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <div className="mb-2 text-xs font-semibold text-slate-200">Add Bulk Session</div>
                <div className="grid grid-cols-[1fr_auto] gap-2">
                  <Input
                    type="number"
                    min={1}
                    max={50}
                    value={bulkCount}
                    onChange={(event) => setBulkCount(event.target.value)}
                    placeholder="Jumlah"
                    className="rounded-2xl border-white/10 bg-white/5"
                  />
                  <Button variant="outline" onClick={() => void handleBulkConnect()} disabled={connecting} className="rounded-2xl border-white/10 bg-white/5">
                    {connecting ? <SpinnerGap className="size-4 animate-spin" /> : <Cpu className="size-4" />}Add Bulk
                  </Button>
                </div>
                <div className="mt-2 text-[11px] text-muted-foreground">Untuk Android Device, tiap session otomatis memakai Device ID baru.</div>
              </div>
              {feedback ? <div className={`rounded-2xl border px-3 py-2 text-xs ${feedback.kind === "error" ? "border-red-500/30 bg-red-500/10 text-red-100" : "border-emerald-500/30 bg-emerald-500/10 text-emerald-100"}`}>{feedback.message}</div> : null}
            </CardContent>
          </Card>

          <Card className="glass-dark rounded-3xl border-white/10">
            <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2 text-base"><Cpu className="size-4" />Session Manager</CardTitle><CardDescription>Kontrol cepat untuk bot yang sedang berjalan.</CardDescription></CardHeader>
            <CardContent className="grid gap-3">
              <div className="grid gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-3">
                <div className="text-xs font-semibold text-slate-200">Mine Level</div>
                <Select value={mineLevel} onValueChange={setMineLevel}>
                  <SelectTrigger className="h-9 rounded-2xl border-white/10 bg-white/5 text-xs"><SelectValue placeholder="Pilih level" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Level 1</SelectItem>
                    <SelectItem value="2">Level 2</SelectItem>
                    <SelectItem value="3">Level 3</SelectItem>
                    <SelectItem value="4">Level 4</SelectItem>
                    <SelectItem value="5">Level 5</SelectItem>
                  </SelectContent>
                </Select>
                <div className="text-[11px] text-muted-foreground">World tetap MINEWORLD, level dipilih dari selector internal.</div>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  <Select value={moveSpeed} onValueChange={setMoveSpeed}>
                    <SelectTrigger className="h-9 rounded-2xl border-white/10 bg-white/5 text-xs"><SelectValue placeholder="Move speed" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="220">Move Safe · 220ms</SelectItem>
                      <SelectItem value="160">Move Normal · 160ms</SelectItem>
                      <SelectItem value="110">Move Fast · 110ms</SelectItem>
                      <SelectItem value="80">Move Turbo · 80ms</SelectItem>
                      <SelectItem value="55">Move Extreme · 55ms</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={breakSpeed} onValueChange={setBreakSpeed}>
                    <SelectTrigger className="h-9 rounded-2xl border-white/10 bg-white/5 text-xs"><SelectValue placeholder="Break speed" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="450">Break Safe · 450ms</SelectItem>
                      <SelectItem value="300">Break Normal · 300ms</SelectItem>
                      <SelectItem value="180">Break Fast · 180ms</SelectItem>
                      <SelectItem value="120">Break Turbo · 120ms</SelectItem>
                      <SelectItem value="80">Break Extreme · 80ms</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Select value={mineSpeed} onValueChange={setMineSpeed}>
                  <SelectTrigger className="h-9 rounded-2xl border-white/10 bg-white/5 text-xs"><SelectValue placeholder="Scan tick" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="800">Scan Safe · 800ms</SelectItem>
                    <SelectItem value="500">Scan Normal · 500ms</SelectItem>
                    <SelectItem value="300">Scan Fast · 300ms</SelectItem>
                    <SelectItem value="220">Scan Turbo · 220ms</SelectItem>
                  </SelectContent>
                </Select>
                <div className="grid grid-cols-1 gap-2 text-xs">
                  <Button type="button" size="sm" variant={breakGemBlocks ? "default" : "outline"} className="justify-start rounded-2xl" onClick={() => setBreakGemBlocks((v) => !v)}>Break Gem Blocks: {breakGemBlocks ? "ON" : "OFF"}</Button>
                  <Button type="button" size="sm" variant={killMonsters ? "default" : "outline"} className="justify-start rounded-2xl" onClick={() => setKillMonsters((v) => !v)}>Kill Monsters: {killMonsters ? "ON" : "OFF"}</Button>
                  <Button type="button" size="sm" variant={collectCollectables ? "default" : "outline"} className="justify-start rounded-2xl" onClick={() => setCollectCollectables((v) => !v)}>Collect All Items: {collectCollectables ? "ON" : "OFF"}</Button>
                  <Button type="button" size="sm" variant={autoUpgradeInventory ? "default" : "outline"} className="justify-start rounded-2xl" onClick={() => setAutoUpgradeInventory((v) => !v)}>Auto Upgrade Inventory: {autoUpgradeInventory ? "ON" : "OFF"}</Button>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-[11px] text-muted-foreground">Auto Repair Pickaxe Kit #4161 aktif otomatis. Collect All Items berjalan ke tile item lalu menunggu pickup otomatis.</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void listSessions().then((payload) => setSessions(sortSessions(payload.sessions ?? [])))}><ArrowClockwise className="size-4" />Refresh</Button>
                <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => runAll((session) => reconnectSession(session.id))}>Reconnect All</Button>
                <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runTutorialAllSessions()}>Tutorial All Session</Button>
                <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAutomineAllSessions()}>Automine All</Button>
                <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void stopAutomineAllSessions()}>Stop Automine All</Button>
                <Button size="sm" variant="destructive" className="rounded-2xl" onClick={() => runAll((session) => terminateSessionAndRemove(session.id))}>Terminate All</Button>
              </div>
              <div className="max-h-[330px] overflow-y-auto pr-1">
                <div className="grid gap-2">
                  {sessions.map((session) => (
                    <div key={session.id} className={`rounded-2xl border p-3 text-left transition-all ${activeSessionId === session.id ? "border-primary/50 bg-primary/10" : "border-white/10 bg-white/[0.03] hover:bg-white/[0.06]"}`}>
                      <button type="button" onClick={() => setActiveSessionId(session.id)} className="w-full text-left">
                        <div className="flex items-center justify-between gap-2"><span className="truncate text-sm font-bold">{sessionDisplayName(session)}</span><Badge variant={statusVariant(session.status)} className="rounded-full text-[10px]">{session.status}</Badge></div>
                        <div className="mt-1 truncate text-[11px] text-muted-foreground">{session.id} · {session.current_world ?? "no world"} · ping {session.ping_ms ?? "-"}ms</div>
                      </button>
                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <Button size="xs" className="rounded-xl" onClick={() => { setActiveSessionId(session.id); void runAction(() => automateTutorial(session.id)) }}>
                          Tutorial
                        </Button>
                        <Button size="xs" variant="outline" className="rounded-xl border-white/10 bg-white/5" onClick={() => { setActiveSessionId(session.id); void runAction(() => startAutomine(session.id, automineOptions())) }}>
                          Automine
                        </Button>
                        <Button size="xs" variant="outline" className="rounded-xl border-white/10 bg-white/5" onClick={() => { setActiveSessionId(session.id); void runAction(() => stopAutomine(session.id)) }}>
                          Stop Mine
                        </Button>
                        <Button size="xs" variant="outline" className="rounded-xl border-white/10 bg-white/5" onClick={() => { setActiveSessionId(session.id); void runAction(() => reconnectSession(session.id)) }}>
                          Reconnect
                        </Button>
                        <Button size="xs" variant="destructive" className="rounded-xl" onClick={() => { setActiveSessionId(session.id); void runAction(() => terminateSessionAndRemove(session.id)) }}>
                          Terminate
                        </Button>
                      </div>
                    </div>
                  ))}
                  {!sessions.length ? <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center text-xs text-muted-foreground">Belum ada session.</div> : null}
                </div>
              </div>
            </CardContent>
          </Card>
        </aside>

        <main className="grid gap-5">
          <Card className="glass rounded-3xl border-white/10 shadow-2xl">
            <CardContent className="p-4">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <div className="flex items-center gap-2 text-lg font-bold"><Lightning className="size-5 text-primary" />Rawa Rontek Control Center</div>
                  <div className="text-xs text-muted-foreground">Pilih session di kiri, jalankan aksi, dan pantau debug log realtime.</div>
                </div>
                {activeSession ? <div className="flex flex-wrap gap-2"><Badge className="rounded-full bg-white/10">{activeSession.id}</Badge><Badge variant={statusVariant(activeSession.status)} className="rounded-full">{activeSession.status}</Badge><Badge className="rounded-full bg-white/10">{activeSession.current_world ?? "no world"}</Badge></div> : null}
              </div>
            </CardContent>
          </Card>

          {activeSession ? (
            <Tabs defaultValue="control" className="grid gap-4">
              <TabsList className="flex w-full flex-wrap justify-start gap-2 rounded-3xl border border-white/10 bg-black/20 p-2">
                <TabsTrigger value="control" className="rounded-2xl px-4">Control</TabsTrigger>
                <TabsTrigger value="automation" className="rounded-2xl px-4">Automation</TabsTrigger>
                <TabsTrigger value="items" className="rounded-2xl px-4">Item Bot</TabsTrigger>
                <TabsTrigger value="lua" className="rounded-2xl px-4">Lua Executor</TabsTrigger>
                <TabsTrigger value="debug" className="rounded-2xl px-4">Debug</TabsTrigger>
              </TabsList>

              <TabsContent value="control" className="mt-0 grid gap-4 2xl:grid-cols-[1fr_520px]">
                <div className="grid gap-4">
                  <Panel title="World & Session" icon={<Plug className="size-4" />}>
                    <div className="grid gap-2 md:grid-cols-[1fr_auto_auto_auto_auto]">
                      <Input value={inputs.world} onChange={(event) => mutateSessionInput(activeSession.id, "world", event.target.value)} placeholder="World name" className="rounded-2xl border-white/10 bg-white/5" />
                      <Button className="rounded-2xl" onClick={() => void runAction(() => joinWorld(activeSession.id, inputs.world))}>Join</Button>
                      <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => leaveWorld(activeSession.id))}>Leave</Button>
                      <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => reconnectSession(activeSession.id))}>Reconnect</Button>
                      <Button variant="destructive" className="rounded-2xl" onClick={() => void runAction(() => terminateSessionAndRemove(activeSession.id))}>Terminate</Button>
                    </div>
                  </Panel>

                  <Panel title="Movement Matrix" icon={<GameController className="size-4" />}>
                    <div className="mx-auto grid max-w-sm gap-2">
                      <div className="grid grid-cols-3 gap-2"><div /><Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => moveSession(activeSession.id, "up"))}>Up</Button><div /></div>
                      <div className="grid grid-cols-3 gap-2"><Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => moveSession(activeSession.id, "left"))}>Left</Button><Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => moveSession(activeSession.id, "down"))}>Down</Button><Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => moveSession(activeSession.id, "right"))}>Right</Button></div>
                    </div>
                  </Panel>

                  <Panel title="Chat" icon={<ChatCenteredDots className="size-4" />}>
                    <div className="grid gap-2 md:grid-cols-[1fr_auto]">
                      <Input value={inputs.chat} onChange={(event) => mutateSessionInput(activeSession.id, "chat", event.target.value)} placeholder="Message" className="rounded-2xl border-white/10 bg-white/5" />
                      <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => talk(activeSession.id, inputs.chat))}>Send</Button>
                    </div>
                  </Panel>
                </div>

                <Card className="glass-dark rounded-3xl border-white/10">
                  <CardHeader><CardTitle className="text-base">Live Minimap</CardTitle><CardDescription>Auto refresh saat session masuk world.</CardDescription></CardHeader>
                  <CardContent>{minimaps[activeSession.id] ? <MinimapPanel minimap={minimaps[activeSession.id]} playerPosition={activeSession.player_position} aiEnemies={activeSession.ai_enemies} otherPlayers={activeSession.other_players} currentWorld={activeSession.current_world} currentTarget={activeSession.current_target} collectables={activeSession.collectables} onHoverChange={() => undefined} /> : <div className="rounded-2xl border border-white/10 bg-white/5 p-8 text-center text-xs text-muted-foreground">Minimap belum tersedia.</div>}</CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="automation" className="mt-0 grid gap-4 xl:grid-cols-2">
                <Panel title="Tutorial / Automine" icon={<Bug className="size-4" />}>
                  <div className="grid gap-2">
                    <Select value={mineLevel} onValueChange={setMineLevel}>
                      <SelectTrigger className="rounded-2xl border-white/10 bg-white/5"><SelectValue placeholder="Pilih mine level" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Mine Level 1</SelectItem>
                        <SelectItem value="2">Mine Level 2</SelectItem>
                        <SelectItem value="3">Mine Level 3</SelectItem>
                        <SelectItem value="4">Mine Level 4</SelectItem>
                        <SelectItem value="5">Mine Level 5</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="grid gap-2 md:grid-cols-3">
                      <Select value={moveSpeed} onValueChange={setMoveSpeed}>
                        <SelectTrigger className="rounded-2xl border-white/10 bg-white/5"><SelectValue placeholder="Move speed" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="220">Move Safe · 220ms</SelectItem>
                          <SelectItem value="160">Move Normal · 160ms</SelectItem>
                          <SelectItem value="110">Move Fast · 110ms</SelectItem>
                          <SelectItem value="80">Move Turbo · 80ms</SelectItem>
                          <SelectItem value="55">Move Extreme · 55ms</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select value={breakSpeed} onValueChange={setBreakSpeed}>
                        <SelectTrigger className="rounded-2xl border-white/10 bg-white/5"><SelectValue placeholder="Break speed" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="450">Break Safe · 450ms</SelectItem>
                          <SelectItem value="300">Break Normal · 300ms</SelectItem>
                          <SelectItem value="180">Break Fast · 180ms</SelectItem>
                          <SelectItem value="120">Break Turbo · 120ms</SelectItem>
                          <SelectItem value="80">Break Extreme · 80ms</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select value={mineSpeed} onValueChange={setMineSpeed}>
                        <SelectTrigger className="rounded-2xl border-white/10 bg-white/5"><SelectValue placeholder="Scan tick" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="800">Scan Safe · 800ms</SelectItem>
                          <SelectItem value="500">Scan Normal · 500ms</SelectItem>
                          <SelectItem value="300">Scan Fast · 300ms</SelectItem>
                          <SelectItem value="220">Scan Turbo · 220ms</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                      <Button type="button" variant={breakGemBlocks ? "default" : "outline"} className="rounded-2xl" onClick={() => setBreakGemBlocks((v) => !v)}>Break Gem Blocks {breakGemBlocks ? "ON" : "OFF"}</Button>
                      <Button type="button" variant={killMonsters ? "default" : "outline"} className="rounded-2xl" onClick={() => setKillMonsters((v) => !v)}>Kill Monsters {killMonsters ? "ON" : "OFF"}</Button>
                      <Button type="button" variant={collectCollectables ? "default" : "outline"} className="rounded-2xl" onClick={() => setCollectCollectables((v) => !v)}>Collect All Items {collectCollectables ? "ON" : "OFF"}</Button>
                    </div>
                    <Button type="button" variant={autoUpgradeInventory ? "default" : "outline"} className="rounded-2xl" onClick={() => setAutoUpgradeInventory((v) => !v)}>Auto Upgrade Inventory {autoUpgradeInventory ? "ON" : "OFF"}</Button>
                    <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-[11px] text-muted-foreground">Auto Repair Pickaxe Kit #4161 aktif otomatis. Jika inventory penuh dan gems mencukupi, sistem akan mencoba upgrade inventory otomatis.</div>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                      <Button className="rounded-2xl" onClick={() => void runAction(() => automateTutorial(activeSession.id))}>Run Tutorial</Button>
                      <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => startAutomine(activeSession.id, automineOptions()))}>Start Lv.{selectedMineLevel()}</Button>
                      <Button variant="destructive" className="rounded-2xl" onClick={() => void runAction(() => stopAutomine(activeSession.id))}>Stop Automine</Button>
                    </div>
                    <div className="text-[11px] text-muted-foreground">Klik Start akan masuk MINEWORLD, memilih level, memakai Move Speed + Break Speed pilihan, lalu Break Gem Blocks / Kill Monsters / Collect All Items. Item dipickup pasif dengan berdiri di tile item.</div>
                  </div>
                </Panel>

                <Panel title="Fishing" icon={<Fish className="size-4" />}>
                  <Input value={inputs.bait} onChange={(event) => mutateSessionInput(activeSession.id, "bait", event.target.value)} placeholder="Bait/lure name" className="rounded-2xl border-white/10 bg-white/5" />
                  <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
                    <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => startFishing(activeSession.id, "left", inputs.bait))}>Fish Left</Button>
                    <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => startFishing(activeSession.id, "right", inputs.bait))}>Fish Right</Button>
                    <Button variant="destructive" className="rounded-2xl" onClick={() => void runAction(() => stopFishing(activeSession.id))}>Stop</Button>
                  </div>
                </Panel>

                <Panel title="Spam Chat" icon={<ChatCenteredDots className="size-4" />}>
                  <div className="grid gap-2 md:grid-cols-[1fr_120px]">
                    <Input value={inputs.spam} onChange={(event) => mutateSessionInput(activeSession.id, "spam", event.target.value)} placeholder="Spam message" className="rounded-2xl border-white/10 bg-white/5" />
                    <Input value={inputs.spamDelay} onChange={(event) => mutateSessionInput(activeSession.id, "spamDelay", event.target.value)} placeholder="Delay s" className="rounded-2xl border-white/10 bg-white/5" />
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-2"><Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => startSpam(activeSession.id, inputs.spam, parseSpamDelayMs(inputs.spamDelay)))}>Start Spam</Button><Button variant="destructive" className="rounded-2xl" onClick={() => void runAction(() => stopSpam(activeSession.id))}>Stop Spam</Button></div>
                </Panel>

                <Panel title="Lua Runner" icon={<TerminalWindow className="size-4" />}>
                  <Textarea value={inputs.luaSource} onChange={(event) => mutateSessionInput(activeSession.id, "luaSource", event.target.value)} rows={9} placeholder='log("hello")' className="rounded-2xl border-white/10 bg-black/40 font-mono text-xs" />
                  <div className="mt-2 grid grid-cols-2 gap-2"><Button variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => void runAction(() => startLuaScript(activeSession.id, inputs.luaSource))}>Run Lua</Button><Button variant="destructive" className="rounded-2xl" onClick={() => void runAction(() => stopLuaScript(activeSession.id))}><StopCircle className="size-4" />Stop Lua</Button></div>
                  {luaStatuses[activeSession.id]?.last_error ? <div className="mt-2 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-2 text-xs text-rose-100">{luaStatuses[activeSession.id]?.last_error}</div> : null}
                </Panel>
              </TabsContent>


              <TabsContent value="lua" className="mt-0 grid gap-4 xl:grid-cols-[minmax(0,1.2fr)_420px]">
                <Panel title="Lua Executor" icon={<TerminalWindow className="size-4" />}>
                  <div className="grid gap-3">
                    <div className="grid gap-2 sm:grid-cols-5">
                      <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => loadLuaTemplate(activeSession.id, "quickStatus")}>Status</Button>
                      <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => loadLuaTemplate(activeSession.id, "worldFlow")}>World Flow</Button>
                      <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => loadLuaTemplate(activeSession.id, "passiveCollect")}>Passive Collect</Button>
                      <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => loadLuaTemplate(activeSession.id, "inventoryReport")}>Inventory</Button>
                      <Button size="sm" variant="outline" className="rounded-2xl border-white/10 bg-white/5" onClick={() => loadLuaTemplate(activeSession.id, "eventWatch")}>Events</Button>
                    </div>
                    <Textarea
                      value={inputs.luaSource}
                      onChange={(event) => mutateSessionInput(activeSession.id, "luaSource", event.target.value)}
                      rows={18}
                      spellCheck={false}
                      placeholder='log("hello from Rawa Rontek")'
                      className="min-h-[460px] rounded-3xl border-white/10 bg-black/50 font-mono text-xs leading-relaxed shadow-inner shadow-black/40"
                    />
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_1fr_auto]">
                      <Button className="rounded-2xl" onClick={() => void runAction(() => startLuaScript(activeSession.id, inputs.luaSource))}>Run Script</Button>
                      <Button variant="destructive" className="rounded-2xl" onClick={() => void runAction(() => stopLuaScript(activeSession.id))}><StopCircle className="size-4" /> Stop Script</Button>
                      <Badge className="justify-center rounded-2xl bg-white/10 px-4 py-2">{luaStatuses[activeSession.id]?.running ? "RUNNING" : "IDLE"}</Badge>
                    </div>
                    {luaStatuses[activeSession.id]?.last_error ? <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-100">{luaStatuses[activeSession.id]?.last_error}</div> : null}
                  </div>
                </Panel>

                <div className="grid gap-4">
                  <Panel title="Lua API Docs" icon={<TerminalWindow className="size-4" />}>
                    <div className="grid gap-3">
                      <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/10 p-3 text-xs text-cyan-100">
                        Mode ini memakai executor per-session. Script berjalan cancellable, log masuk ke console, dan template di atas memakai API aman berbasis <span className="font-mono">bot</span> untuk session aktif.
                      </div>
                      <div className="grid max-h-[560px] gap-3 overflow-y-auto pr-1">
                        {LUA_API_GROUPS.map((group) => (
                          <div key={group.title} className="rounded-2xl border border-white/10 bg-white/5 p-3">
                            <div className="mb-2 text-xs font-bold uppercase tracking-widest text-slate-300">{group.title}</div>
                            <div className="grid gap-1">
                              {group.items.map((item) => <code key={item} className="rounded-xl bg-black/30 px-2 py-1 text-[11px] text-cyan-100">{item}</code>)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Panel>
                  <Console title="Lua Console" logs={activeLogs.filter((log) => log.scope === "lua" || log.scope === "session").slice(-120)} formatLogTime={formatLogTime} />
                </div>
              </TabsContent>

              <TabsContent value="items" className="mt-0 grid gap-4">
                <Panel title="Item Bot / Inventory Storage" icon={<TShirt className="size-4" />}>
                  <div className="mb-3 rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-xs text-muted-foreground">
                    Semua item dari session aktif ditampilkan di sini. Item wearable bisa dipakai/dilepas, item lain bisa di-drop sesuai jumlah.
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
                    {activeSession.inventory.length ? activeSession.inventory.map((item) => {
                      const blockName = blockNames[String(item.block_id)]
                      const label = blockName && blockName !== "None" ? camelToWords(blockName) : `#${item.block_id}`
                      const key = `${activeSession.id}-${item.block_id}-${item.inventory_type}`
                      return (
                        <div key={key} className="grid gap-2 rounded-2xl border border-white/10 bg-white/5 p-3 text-center shadow-lg shadow-black/10">
                          <TileSprite blockId={item.block_id} size={44} className="mx-auto" fallback={<span className="text-[10px] text-muted-foreground">?</span>} />
                          <div className="font-mono text-[11px] text-muted-foreground">#{item.block_id}</div>
                          <div className="min-h-8 text-sm font-semibold text-slate-100">{label}</div>
                          <div className="text-xl font-black text-cyan-300">x{item.amount}</div>
                          <div className="rounded-full border border-white/10 bg-black/20 px-2 py-1 text-[11px] text-muted-foreground">
                            {getItemCategory(blockName, inventoryTypeLabel(item.inventory_type))}
                          </div>
                          {CLOTHING_TYPES.has(item.inventory_type) ? (
                            <div className="grid grid-cols-2 gap-2">
                              <Button size="xs" variant="outline" className="rounded-xl border-white/10 bg-white/5" onClick={() => void runAction(() => wearItem(activeSession.id, item.block_id, true))}>Wear</Button>
                              <Button size="xs" variant="outline" className="rounded-xl border-white/10 bg-white/5" onClick={() => void runAction(() => wearItem(activeSession.id, item.block_id, false))}>Off</Button>
                            </div>
                          ) : null}
                          <div className="grid grid-cols-[1fr_auto] gap-2">
                            <Input
                              className="h-8 rounded-xl border-white/10 bg-white/5 text-center text-xs"
                              type="number"
                              min={1}
                              max={item.amount}
                              value={dropAmounts[key] ?? "1"}
                              onChange={(event) => setDropAmounts((current) => ({ ...current, [key]: event.target.value }))}
                            />
                            <Button
                              size="xs"
                              variant="outline"
                              className="rounded-xl border-white/10 bg-white/5"
                              onClick={() => {
                                const amount = Math.max(1, Math.min(item.amount, parseInt(dropAmounts[key] ?? "1", 10) || 1))
                                void runAction(() => dropItem(activeSession.id, item.block_id, item.inventory_type, amount))
                              }}
                            >
                              Drop
                            </Button>
                          </div>
                        </div>
                      )
                    }) : (
                      <div className="rounded-2xl border border-dashed border-white/10 bg-white/5 px-4 py-8 text-center text-sm text-muted-foreground">Inventory session ini masih kosong.</div>
                    )}
                  </div>
                </Panel>
              </TabsContent>

              <TabsContent value="debug" className="mt-0 grid gap-4 xl:grid-cols-[1fr_420px]">
                <Console title="Session Console" logs={activeLogs} formatLogTime={formatLogTime} />
                <Card className="glass-dark rounded-3xl border-white/10"><CardHeader><CardTitle className="text-base">Session Detail</CardTitle></CardHeader><CardContent className="grid gap-2 text-xs"><Detail label="Bot Name" value={sessionDisplayName(activeSession)} /><Detail label="ID" value={activeSession.id} /><Detail label="User" value={activeSession.username ?? "-"} /><Detail label="World" value={activeSession.current_world ?? "-"} /><Detail label="Host" value={`${activeSession.current_host}:${activeSession.current_port}`} /><Detail label="Position" value={`${activeSession.player_position.map_x ?? "-"}, ${activeSession.player_position.map_y ?? "-"}`} /><Detail label="Inventory" value={`${activeSession.inventory.length} item`} /><Detail label="Collectables" value={`${activeSession.collectables.length}`} /><Detail label="Last Error" value={activeSession.last_error ?? "-"} /></CardContent></Card>
              </TabsContent>
            </Tabs>
          ) : <Card className="glass rounded-3xl border-white/10"><CardContent className="p-12 text-center text-sm text-muted-foreground">Connect bot dulu untuk membuat session.</CardContent></Card>}

          <Console title="Global Debug Console" logs={filteredLogs.slice(-160)} formatLogTime={formatLogTime} filter={logScopeFilter} setFilter={setLogScopeFilter} clear={() => setLogs([])} />
        </main>
      </div>
    </div>
  )
}

function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded-2xl border border-white/10 bg-white/5 p-3"><div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div><div className="text-xl font-black text-slate-100">{value}</div></div>
}

function Detail({ label, value }: { label: string; value: string }) {
  return <div className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 px-3 py-2"><span className="text-muted-foreground">{label}</span><span className="truncate font-semibold text-slate-100">{value}</span></div>
}

function Panel({ title, icon, children }: { title: string; icon: ReactNode; children: ReactNode }) {
  return <Card className="glass-dark rounded-3xl border-white/10"><CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-base">{icon}{title}</CardTitle></CardHeader><CardContent>{children}</CardContent></Card>
}

function Console({ title, logs, formatLogTime, filter, setFilter, clear }: { title: string; logs: LogEvent[]; formatLogTime: (timestampMs: number) => string; filter?: string; setFilter?: (value: string) => void; clear?: () => void }) {
  return <Card className="glass-dark rounded-3xl border-white/10"><CardHeader className="pb-3"><div className="flex items-center justify-between gap-3"><div><CardTitle className="flex items-center gap-2 text-base"><TerminalWindow className="size-4" />{title}</CardTitle><CardDescription>{logs.length} log ditampilkan.</CardDescription></div>{clear ? <Button size="xs" variant="outline" className="rounded-xl border-white/10 bg-white/5" onClick={clear}>Clear</Button> : null}</div>{filter && setFilter ? <Select value={filter} onValueChange={setFilter}><SelectTrigger className="mt-2 h-8 rounded-2xl border-white/10 bg-white/5 text-xs"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All Logs</SelectItem><SelectItem value="active">Active Session</SelectItem><SelectItem value="action">Action</SelectItem><SelectItem value="lua">Lua</SelectItem><SelectItem value="automine">Automine</SelectItem><SelectItem value="tutorial">Tutorial</SelectItem><SelectItem value="error">Errors</SelectItem></SelectContent></Select> : null}</CardHeader><CardContent><div className="max-h-[430px] overflow-y-auto rounded-2xl border border-white/10 bg-black/60 p-2 font-mono text-[10px] leading-relaxed text-slate-200">{logs.map((log, index) => <div key={`${log.timestamp_ms}-${index}`} className="grid grid-cols-[62px_74px_1fr] gap-2 border-b border-white/5 py-1 last:border-b-0"><span className="text-slate-500">{formatLogTime(log.timestamp_ms)}</span><span className={`rounded border px-1 text-center uppercase ${log.level === "error" ? "border-rose-500/40 bg-rose-500/10 text-rose-200" : log.level === "warn" ? "border-amber-500/40 bg-amber-500/10 text-amber-200" : "border-cyan-500/30 bg-cyan-500/10 text-cyan-200"}`}>{log.scope}</span><span className="break-words">{log.session_id ? `[${log.session_id}] ` : ""}{log.message}</span></div>)}{!logs.length ? <div className="py-8 text-center text-muted-foreground">Waiting for logs...</div> : null}</div></CardContent></Card>
}

export default App
