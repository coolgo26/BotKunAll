# Mirai Lua API

Complete API reference for the Mirai Lua executor. The executor runs a single
global script at a time. Scripts reach bots by name through `getBot` or create
new ones with `addDevice` / `addClient`.

---

## Runtime Model

- One script runs at a time per slot. Starting a new script cancels the previous one.
- The script runs in its own worker task, separate from any bot's socket loop.
- Lua calls send commands to bots; they do not mutate sessions directly.
- Long-running scripts are cancellable through a Lua instruction hook.
- Server shutdown cancels the active script.
- Cooperative coroutines are supported via `runThread` / `task.spawn`.

---

## Globals

### `getBot(name)`

Returns a bot handle for the bot with the given id, or `nil` if no bot with
that id exists.

```lua
local b = getBot("alpha")
if b == nil then
  log("alpha is not running")
  return
end
```

### `getBots()`

Returns an array of all active bot id strings.

```lua
local ids = getBots()
for _, id in ipairs(ids) do
  log("bot:", id)
end
```

### `addDevice([device_id])`

Creates a new bot with a random (or specified) Android device ID and returns a
bot handle. The bot starts in a disconnected/idle state — call `b:connect()` to
go online. Omit `device_id` to auto-generate one.

Not available in single-instance scope.

```lua
local bot = addDevice()
print("Bot: " .. bot:name())
bot:connect()
```

### `addClient(email, password)`

Creates a new bot with email/password credentials and returns a bot handle. The
bot starts idle — call `b:connect()` to go online.

Not available in single-instance scope.

```lua
local bot = addClient("user@example.com", "pass123")
bot:connect()
```

### `removeClient(id)`

Removes a bot by its id. Returns `true` if the bot existed and was removed.

Not available in single-instance scope.

```lua
removeClient("device_abc12345")
```

### `getClients()`

Returns an array of bot handles for all active bots (not just ids — actual
handles you can call methods on).

```lua
local bots = getClients()
for _, b in ipairs(bots) do
  log(b:name(), b:state())
end
```

### `log(...)` / `print(...)`

Writes a line to the script output log. Multiple arguments are joined with a
single space. `print` is an alias for `log`.

```lua
log("started")
log("pos:", b:pos().tile_x, b:pos().tile_y)
```

### `sleep(ms)`

Pauses the script for `ms` milliseconds. Cancellable — if the script is stopped
while sleeping, the sleep returns immediately. Inside a coroutine (`runThread`
/ `task.spawn`), sleep yields instead of blocking the entire script.

```lua
sleep(5000)  -- wait 5 seconds
```

`sleep_ms` is an alias for `sleep`.

### `now_ms()`

Returns the current time in milliseconds (monotonic clock). Useful for
timeouts and delays.

```lua
local deadline = now_ms() + 30000
while now_ms() < deadline do
  sleep(1000)
end
```

### `getItemInfo(id)`

Returns an item info table from the block database, or `nil` if the id is
unknown.

```lua
local info = getItemInfo(242)
if info then
  log(info.name, "seed:", info.is_seed, "tradeable:", info.is_tradeable)
end
```

Fields:

| Field                | Type    | Description                       |
|----------------------|---------|-----------------------------------|
| `id`                 | number  | Block/item id                     |
| `name`               | string  | Display name                      |
| `is_seed`            | boolean | Whether this item is a seed       |
| `is_tradeable`       | boolean | Whether this item can be traded   |
| `has_collider`       | boolean | Whether the block has collision   |
| `is_one_way`         | boolean | Whether the block is one-way      |
| `hits_required`      | number  | Hits to break                     |
| `growth_time`        | number  | Seed growth time in seconds       |
| `block_class`        | number  | Block class enum value            |
| `inventory_item_type`| number  | Inventory type classification     |
| `level_requirement`  | number  | Level needed to use               |
| `description`        | string? | Item description (may be nil)     |

### `getItemInfos()`

Returns a table of **all** item info entries, keyed by item id. Each entry has
the same fields as `getItemInfo`.

```lua
local all = getItemInfos()
for id, info in pairs(all) do
  if info.is_seed then
    log(id, info.name, "grows in", info.growth_time, "s")
  end
end
```

### `SLOT_ID`

String global containing the script slot identifier.

### `EXECUTION_SCOPE`

String global describing the execution scope. Either `"global"` or
`"single:<bot_id>"`.

---

## Bot Handle

`getBot` / `addDevice` / `addClient` return a userdata handle. Methods are
called with the colon syntax (`b:method(args)`). Each call re-resolves the bot
from the manager, so a handle held across a bot removal will fail with
`bot '<id>' not found` rather than acting on stale state.

### Connection & State

#### `b:name()`

Returns the bot id this handle points at.

```lua
log(b:name())
```

#### `b:connect()`

Connects the bot to the game server.

```lua
bot:connect()
```

#### `b:disconnect()`

Disconnects the bot from the game server.

```lua
bot:disconnect()
```

#### `b:state()`

Returns the bot's current state as a string. Possible values:
`"Created"`, `"Disconnected"`, `"Connecting"`, `"MenuIdle"`, `"LoadingWorld"`,
`"SpawnSetup"`, `"InWorld"`, `"Failed"`, `"Dead"`.

```lua
local s = bot:state()
if s == "InWorld" then log("in world") end
```

#### `b:connected()`

Returns `true` if the bot is currently connected (`InWorld` or `MenuIdle`).

```lua
if bot:connected() then log("online") end
```

#### `b:start_tutorial()`

Starts the tutorial sequence. Listen for `events.TUTORIAL_COMPLETED` to know
when it finishes.

```lua
bot:once(events.TUTORIAL_COMPLETED, function() print("done") end)
bot:start_tutorial()
```

#### `b:get_ping()`

Returns the bot's current ping in milliseconds, or `nil` if no ping sample
has been taken yet (bot not in-world).

```lua
log("ping:", b:get_ping())
```

### Movement & Navigation

#### `b:walk(dx, dy)`

Moves the bot by a joystick-style offset. Values are clamped to `-1..1`.

```lua
b:walk(1, 0)    -- right
b:walk(0, -1)   -- up
b:walk(0, 0)    -- stop
```

#### `b:find_path(tile_x, tile_y)`

Plans a path to the absolute tile `(tile_x, tile_y)`, dispatches the walk, and
**blocks the script until the bot arrives** (up to 15 second timeout).

Coordinates are absolute map tiles, not offsets. Raises a Lua error if pathing
fails (e.g. bot is not in-world, world map not loaded).

```lua
b:find_path(42, 30)
log("arrived")

-- relative movement:
local p = b:pos()
b:find_path(p.tile_x + 5, p.tile_y)
```

#### `b:start_path(x, y)`

Starts pathfinding to tile `(x, y)` **without blocking**. Returns immediately.
Pair with `b:pos()` polling so multiple bots can move at the same time from a
single script.

```lua
b:start_path(42, 30)
-- do other work...
```

#### `b:walkTo(x, y)`

Alias for `find_path` — plans a path to absolute tile `(x, y)` and blocks
until arrival.

```lua
b:walkTo(42, 30)
```

### World Navigation

#### `b:warp(world [, special])`

Warps the bot into `world`. `special` defaults to `false`.

Supports portal targeting with the `world:portalId` syntax. When a portal ID is
provided, the bot spawns directly at the portal's tile position.

```lua
b:warp("PIXELSTATION")
b:warp("NETHERWORLD", true)
b:warp("Rohumets:Byte67")   -- spawn at portal "Byte67"
```

#### `b:join_world(world_str)`

Same as `warp` but always non-special. Supports `world:portalId` format.

```lua
b:join_world("Rohumets:Byte67")
```

#### `b:enter_portal(portal_id)`

Teleports the bot to the portal with the given `entryPointID` in the current
world and enters it (sends PortalApproach + PortalInside). The bot must already
be in a world.

```lua
b:enter_portal("Byte67")
```

#### `b:leave()`

Leaves the current world and returns the bot to the menu.

```lua
b:leave()
```

#### `b:respawn()`

Respawns the bot at the current world's spawn point.

```lua
b:respawn()
```

### Block Interaction

#### `b:place_block(dx, dy, item_id)`

Places a foreground block at the tile `(bot.tile_x + dx, bot.tile_y + dy)`.
`dx`/`dy` are tile offsets relative to the bot. The y axis grows downward,
so `dy = -1` is one tile up.

```lua
b:place_block(1, 0, 7)    -- place to the right
b:place_block(0, -1, 7)   -- place above
```

#### `b:place(x, y, item_id)`

Places a block at **absolute** tile `(x, y)` (not offset-based).

```lua
b:place(42, 30, 7)
```

#### `b:place_seed(dx, dy, item_id)`

Plants a seed at the offset tile. Same offset rules as `place_block`.

```lua
b:place_seed(1, 0, 2735)
```

#### `b:plant(x, y, item_id)`

Plants a seed at **absolute** tile `(x, y)`.

```lua
b:plant(42, 30, 2735)
```

#### `b:hit_block(dx, dy)`

Hits/breaks the block at offset `(dx, dy)` relative to the bot.

```lua
b:hit_block(1, 0)   -- break block to the right
```

#### `b:hit_block_at(x, y)`

Hits/breaks the block at absolute tile `(x, y)`.

```lua
b:hit_block_at(42, 30)
```

#### `b:hit(x, y)`

Alias for `hit_block_at`.

```lua
b:hit(42, 30)
```

#### `b:select_block(item_id)`

Selects/holds the block with the given item id.

```lua
b:select_block(7)
```

#### `b:start_pnb(item_id, offsets)`

Starts a place-and-break cycle with the given item at the given offsets.

```lua
b:start_pnb(7, { {x=1, y=0}, {x=-1, y=0} })
```

#### `b:stop_pnb()`

Stops the current place-and-break cycle.

### Chat

#### `b:say(message)`

Sends a world chat message. Add your own delay between sends to avoid the
server's spam limit.

```lua
b:say("hello")
```

### Inventory

#### `b:inventory()`

Returns a detailed inventory snapshot table.

```lua
local inv = b:inventory()
log("slots:", inv.size, "used:", inv.used, "free:", inv.free)
for _, item in ipairs(inv.items) do
  log(item.item_id, "x" .. item.amount, "type:" .. item.inventory_type)
end
```

Fields:

| Field  | Type   | Description                                |
|--------|--------|--------------------------------------------|
| `size` | number | Total inventory slots                      |
| `used` | number | Number of occupied slots                   |
| `free` | number | Number of empty slots                      |
| `items`| array  | Array of item tables (see below)           |

Each item in `items`:

| Field            | Type   | Description                    |
|------------------|--------|--------------------------------|
| `item_id`        | number | Block/item id                  |
| `inventory_type` | number | Inventory type classification  |
| `amount`         | number | Quantity held                  |

#### `b:get_inventory()`

Returns the bot's full inventory as an array of item tables (more detailed than
`inventory().items`).

```lua
local inv = b:get_inventory()
for _, item in ipairs(inv) do
  log(item.id, "x" .. item.amount, item.name or "")
end
```

Each item:

| Field            | Type    | Description                    |
|------------------|---------|--------------------------------|
| `id`             | number  | Block/item id                  |
| `amount`         | number  | Quantity held                  |
| `inventory_type` | number  | Inventory type classification  |
| `flags`          | number  | Item flags                     |
| `name`           | string? | Item name (may be nil)         |

#### `b:has_item(block_id [, min])`

Returns `true` if the bot's inventory contains at least `min` (default 1) of
the given block id.

```lua
if b:has_item(7, 10) then log("have 10+ dirt") end
```

#### `b:equip(item_id)`

Equips/wears the item with the given id.

```lua
b:equip(515)  -- JumpsuitMale
```

#### `b:unequip(item_id)`

Unequips the item with the given id.

```lua
b:unequip(515)
```

#### `b:drop(item_id, amount [, inventory_type])`

Drops `amount` of `item_id` from inventory. If `inventory_type` is omitted,
the bot's current inventory is searched and the matching item's
`inventory_type` is used. Errors if the item isn't in inventory and no
`inventory_type` was supplied.

```lua
b:drop(7, 10)         -- drop 10 of item id 7 (auto inventory_type)
b:drop(7, 10, 0)      -- drop 10 with explicit inventory_type
```

### Account

#### `b:get_account()`

Returns account information for the bot, or `nil` if not loaded yet.

```lua
local acc = b:get_account()
if acc then
  log("gems:", acc.gems, "level:", acc.level)
end
```

Fields:

| Field               | Type   | Description                         |
|---------------------|--------|-------------------------------------|
| `gems`              | number | Current gem count                   |
| `level`             | number | Player level                        |
| `xp`                | number | Current XP amount                   |
| `xp_to_next_level`  | number | XP needed for next level            |
| `inventory_slots`   | number | Total inventory slot count          |

### Shop

#### `b:open_shop()`

Opens the in-game shop.

#### `b:close_shop()`

Closes the in-game shop.

#### `b:buy_pack(pack_id)`

Buys the pack with the given id from the shop.

```lua
b:open_shop()
sleep(2000)
b:buy_pack("WorldLock")
sleep(2000)
b:close_shop()
```

### Position & World Data

#### `b:pos()`

Returns the bot's current position.

```lua
local p = b:pos()
log(p.x, p.y, p.tile_x, p.tile_y)
```

Fields:

| Field       | Type   | Description               |
|-------------|--------|---------------------------|
| `x`         | number | World position X (float)  |
| `y`         | number | World position Y (float)  |
| `tile_x`    | number | Map tile X (integer)      |
| `tile_y`    | number | Map tile Y (integer)      |
| `direction` | number | Facing direction          |
| `animation` | number | Current animation state   |

#### `b:position()`

Alias for `pos()`.

#### `b:get_world_name()`

Returns the name of the world the bot is currently in, or `nil`.

```lua
log(bot:get_world_name() or "not in world")
```

#### `b:get_world()`

Returns a snapshot of the world the bot is currently in.

```lua
local w = b:get_world()
log(w.name, w.width .. "x" .. w.height)

local p = b:pos()
log("standing on fg=" .. w:fg_at(p.tile_x, p.tile_y))
```

Top-level fields:

| Field                   | Type    | Description                           |
|-------------------------|---------|---------------------------------------|
| `name`                  | string? | World name, or `nil`                  |
| `width`, `height`       | number  | Map dimensions in tiles               |
| `start`                 | table?  | `{ x, y }` spawn point, or `nil`     |
| `fg` / `foreground`     | array   | 1-based flat array of foreground ids  |
| `bg` / `background`     | array   | 1-based flat array of background ids  |
| `water`                 | array   | 1-based flat array of water values    |
| `wiring`                | array   | 1-based flat array of wiring values   |
| `seeds`                 | array   | Array of planted-seed tables          |

Helper methods on the returned table:

- `w:index(x, y)` — 1-based flat-array index for tile `(x, y)`, or `nil` if
  out of bounds
- `w:fg_at(x, y)` — foreground block id at tile `(x, y)`, or `nil`
- `w:bg_at(x, y)` — background block id at tile `(x, y)`, or `nil`
- `w:seed_at(x, y)` — planted-seed table at `(x, y)`, or `nil`
- `w.tile_item_at(x, y)` — item data table at `(x, y)`, or `nil` (portal data,
  sign text, etc.)
- `w.size()` — returns `{ width, height }` table
- `w.entrance()` — returns `{ x, y }` spawn point, or `nil`

Each seed entry:

| Field                  | Type    | Description                             |
|------------------------|---------|-----------------------------------------|
| `x`, `y`              | number  | Tile position                           |
| `block_type`           | number  | Seed item id                            |
| `growth_duration`      | number  | Growth time value                       |
| `growth_end_time`      | number  | .NET tick value when growth completes   |
| `mixed`                | boolean | Whether the seed is a splice            |
| `harvest_seeds`        | number  | Seeds to harvest                        |
| `harvest_blocks`       | number  | Blocks to harvest                       |
| `harvest_gems`         | number  | Gems to harvest                         |
| `harvest_extra_blocks` | number  | Extra blocks to harvest                 |
| `ready`                | boolean | `true` when harvestable now             |
| `remaining_ms`         | number  | Milliseconds until harvest-ready (0 = ready) |

When the bot has no parsed map (menu state), `width`/`height` are `0`, the
layer arrays are empty tables, and the helper functions are not attached.

#### `b:get_tile(x, y)`

Returns tile info at absolute position `(x, y)`, or `nil` if out of bounds.

```lua
local t = b:get_tile(42, 30)
if t then
  log("fg:", t.fg, "bg:", t.bg, "water:", t.water, "wiring:", t.wiring)
end
```

Fields: `x`, `y`, `fg`, `bg`, `water`, `wiring`.

#### `b:get_tile_item(x, y)`

Returns tile item data at absolute tile `(x, y)`, or `nil`. Fields vary by
item class (portals have `entryPointID`, `targetWorldID`, `class`, `isLocked`,
etc.).

```lua
local item = b:get_tile_item(46, 45)
if item then
  log("class:", item.class, "portal:", item.entryPointID or "none")
end
```

#### `b:world_size()`

Returns a `Vec2i` userdata with `x` = width and `y` = height, or `nil` if
not in a world.

```lua
local s = b:world_size()
if s then log("world is", s.x, "x", s.y) end
```

#### `b:entrance()`

Returns a `Vec2i` userdata for the world's spawn point, or `nil`.

```lua
local e = b:entrance()
if e then log("spawn at", e.x, e.y) end
```

#### `b:isWalkable(x, y)`

Returns `true` if the tile at absolute position `(x, y)` has no foreground
block (i.e. is passable).

```lua
if b:isWalkable(42, 30) then log("can walk there") end
```

#### `b:findTiles(block_type)`

Returns an array of `Vec2i` userdata for all foreground tiles matching
`block_type`.

```lua
local portals = b:findTiles(329)
for _, p in ipairs(portals) do
  log("portal at", p.x, p.y)
end
```

#### `b:seeds()`

Returns an array of planted seed tables in the current world. Each entry has:
`x`, `y`, `block_type`, `ready`, `remaining_ms`, `harvest_seeds`,
`harvest_blocks`, `harvest_gems`.

```lua
for _, seed in ipairs(b:seeds()) do
  if seed.ready then
    log("ready seed at", seed.x, seed.y)
  end
end
```

### Players & Collectables

#### `b:get_players()`

Returns an array of other players in the current world.

```lua
local players = b:get_players()
for _, p in ipairs(players) do
  log(p.username, "at tile", p.tile_x, p.tile_y)
end
```

Each player:

| Field       | Type   | Description                |
|-------------|--------|----------------------------|
| `user_id`   | string | Player's unique user id    |
| `username`  | string | Display name               |
| `x`, `y`    | number | World position (float)     |
| `tile_x`    | number | Map tile X                 |
| `tile_y`    | number | Map tile Y                 |
| `direction` | number | Facing direction           |
| `animation` | number | Current animation          |

#### `b:get_collectables()`

Returns an array of collectables (dropped items/gems) in the current world.

```lua
local items = b:get_collectables()
for _, c in ipairs(items) do
  log("item:", c.block_type, "x" .. c.amount, "at", c.x, c.y)
end
```

Each collectable:

| Field        | Type    | Description                    |
|--------------|---------|--------------------------------|
| `id`         | number  | Collectable id (for collect)   |
| `block_type` | number  | Item id of the collectable     |
| `amount`     | number  | Quantity                       |
| `x`, `y`     | number  | World position                 |
| `is_gem`     | boolean | Whether this is a gem drop     |
| `gem_type`   | number  | Gem type (if `is_gem`)         |

#### `b:collect(collectable_id)`

Collects the item with the given collectable id (from `get_collectables`).

```lua
b:collect(42)
```

#### `b:collectAll()`

Collects all available collectables in the current world. Returns the number
of items collected.

```lua
local count = b:collectAll()
log("collected", count, "items")
```

### Raw Packets

#### `b:send_packet(packet)`

Sends an arbitrary BSON packet to the bot's server connection. `packet` is a
Lua table with string keys.

```lua
b:send_packet({ ID = "WC", MS = "hello world" })
```

Type conversion rules:

| Lua type            | BSON type        |
|---------------------|------------------|
| `nil`               | `null`           |
| `boolean`           | `bool`           |
| `integer` (fits i32)| `int32`          |
| `integer` (else)    | `int64`          |
| `number`            | `double`         |
| `string`            | `string`         |
| array-like table    | `array`          |
| other table         | `document`       |

A table is treated as an array when its keys are exactly `1..N` integers.
Empty tables become empty documents.

`send_packet` is a low-level escape hatch — it does no validation and does not
chain companion packets. The bot must be in-world for the packet to go out.

---

## Events

Bot handles can subscribe to bot-level events:

```lua
local b = getBot("alpha")
b:on(events.PACKET_RECEIVED, function(packet)
  log(packet.ids[1] or "?", packet.seq)
end)

while true do sleep(1000) end  -- keep the script alive
```

Listeners only fire while the script is running. When the script ends or is
stopped, all listeners are released.

### Event Names

The `events` global is a table of constants. Use these instead of raw strings.

| Constant                      | String                 | Payload                    |
|-------------------------------|------------------------|----------------------------|
| `events.PACKET_RECEIVED`      | `"packet_received"`    | packet table               |
| `events.CHAT_MESSAGE`         | `"chat_message"`       | chat message table         |
| `events.STATE_CHANGED`        | `"state_changed"`      | `{ state = "InWorld" }`    |
| `events.JOINED_WORLD`         | `"joined_world"`       | `{ world = "WORLDNAME" }`  |
| `events.ERROR`                | `"error"`              | `{ message = "..." }`      |
| `events.TUTORIAL_COMPLETED`   | `"tutorial_completed"` | `{ completed = true }`     |
| `events.PACK_PURCHASED`       | `"pack_purchased"`     | pack purchase table        |

### `b:on(event, callback)`

Subscribes `callback` to fire every time `event` happens on this bot.

```lua
b:on(events.CHAT_MESSAGE, function(msg)
  log("[" .. msg.channel .. "] " .. msg.username .. ": " .. msg.message)
end)
```

### `b:once(event, callback)`

Same as `on`, but the callback fires at most once and then auto-removes.

```lua
b:once(events.JOINED_WORLD, function(data)
  log("entered:", data.world)
end)
```

### `b:off(event)`

Removes every listener this script registered on this bot for `event`.

```lua
b:off(events.PACKET_RECEIVED)
```

### Event Payloads

#### `packet_received`

```lua
{
  seq = 42,                     -- monotonic sequence id
  at = "2026-05-04T12:34:56Z",  -- RFC3339 timestamp
  direction = "received",        -- "received" or "sent"
  ids = { "MV", "AP" },          -- packet id strings
  document = { ... },            -- decoded packet body as a Lua table
}
```

#### `chat_message`

```lua
{
  channel = "world",        -- chat channel
  user_id = "abc123",       -- sender's user id
  username = "Player1",     -- sender's display name
  message = "hello there",  -- message text
}
```

#### `state_changed`

```lua
{ state = "InWorld" }   -- new bot state as string
```

#### `joined_world`

```lua
{ world = "PIXELSTATION" }
```

#### `error`

```lua
{ message = "connection lost" }
```

#### `pack_purchased`

```lua
{
  pack_id = "WorldLock",       -- pack identifier
  status = "success",          -- purchase status
  rewards = { 242 },           -- array of item ids received
}
```

### Notes & Limits

- Listeners only fire while Lua is actually executing. If your script falls
  off the end with no loop, no events will be dispatched.
- A small queue (1024 events) buffers between the bot and the script. If the
  script can't keep up, the oldest events are dropped first.

---

## Cooperative Threading

Mirai supports cooperative coroutines for running multiple tasks concurrently
within a single script. Threads yield on `sleep()` and resume automatically.

### `runThread(func)`

Starts a cooperative coroutine. The function should call `sleep(ms)` to yield
and be resumed later. Returns a thread id (integer), or `0` if the function
completed immediately.

```lua
local id = runThread(function()
  while true do
    log("tick")
    sleep(1000)
  end
end)
```

Inside a `runThread` function, `sleep()` yields the coroutine instead of
blocking the entire script. This lets you run multiple bots in parallel:

```lua
for _, name in ipairs(botNames) do
  runThread(function()
    local b = getBot(name)
    while true do
      b:say("hello from " .. name)
      sleep(5000)
    end
  end)
end

-- keep the main script alive so threads keep running
while true do sleep(1000) end
```

### `removeThread(id)`

Stops a cooperative thread by its id. Returns `true` if found and removed.

```lua
local id = runThread(function() ... end)
-- later:
removeThread(id)
```

### `task` Module

Alternative API for cooperative threading (same underlying mechanism).

#### `task.spawn(func)`

Same as `runThread` — starts a cooperative coroutine and returns an id.

```lua
local id = task.spawn(function()
  sleep(5000)
  log("delayed task done")
end)
```

#### `task.cancel(id)`

Same as `removeThread` — cancels a cooperative thread.

#### `task.wait(seconds)`

Blocking wait (does NOT yield). Primarily for short delays outside coroutines.

```lua
task.wait(0.5)  -- wait 500ms
```

---

## Vector Types

### `Vector2.new(x, y)`

Creates a 2D float vector.

```lua
local v = Vector2.new(1.5, 2.0)
log(v.x, v.y)        -- 1.5  2.0
```

Methods and operators:

- `v.x`, `v.y` — read/write fields
- `v:equals(other)` — equality check
- `v:point()` — convert to `Vec2i` (floor)
- `v + other`, `v - other` — vector addition/subtraction
- `v * scalar` — scalar multiplication
- `v == other` — equality operator
- `tostring(v)` — `"Vec2(1.5, 2.0)"`

### `Vector2i.new(x, y)`

Creates a 2D integer vector.

```lua
local v = Vector2i.new(42, 30)
log(v.x, v.y)
```

Methods and operators:

- `v.x`, `v.y` — read/write fields
- `v:equals(other)` — equality check
- `v:position()` — convert to `Vec2` (float)
- `v + other`, `v - other` — vector addition/subtraction
- `v * scalar` — scalar multiplication
- `v == other` — equality operator
- `tostring(v)` — `"Vec2i(42, 30)"`

---

## HTTP Client

The `http` module provides HTTP request functions. All methods block until the
response arrives.

### `http.get(url [, opts])`

### `http.post(url [, opts])`

### `http.put(url [, opts])`

### `http.delete(url [, opts])`

### `http.patch(url [, opts])`

All methods accept the same arguments and return the same response table.

**Options table:**

| Field     | Type   | Description                              |
|-----------|--------|------------------------------------------|
| `headers` | table  | Key-value pairs of HTTP headers          |
| `body`    | string | Raw request body                         |
| `json`    | any    | Auto-serialized JSON body (sets Content-Type) |
| `timeout` | number | Request timeout in milliseconds (default 30000) |

If `json` is provided, it is serialized and `Content-Type: application/json`
is set automatically. `body` and `json` are mutually exclusive.

**Response table:**

| Field     | Type    | Description                             |
|-----------|---------|-----------------------------------------|
| `status`  | number  | HTTP status code (200, 404, etc.)       |
| `ok`      | boolean | `true` if status is 200-299             |
| `body`    | string  | Response body as text                   |
| `headers` | table   | Response headers (lowercase keys)       |

```lua
-- Simple GET
local resp = http.get("https://api.example.com/data")
if resp.ok then
  local data = json.decode(resp.body)
  log("got:", data.name)
end

-- POST with JSON body
local resp = http.post("https://hooks.example.com/webhook", {
  json = { content = "Hello from Mirai!" },
  headers = { ["Authorization"] = "Bearer token123" },
  timeout = 10000,
})
log("status:", resp.status)
```

---

## JSON

### `json.encode(value)`

Converts a Lua value to a JSON string.

```lua
local s = json.encode({ name = "test", count = 42 })
log(s)  -- {"name":"test","count":42}
```

### `json.decode(str)`

Parses a JSON string into a Lua value.

```lua
local data = json.decode('{"name":"test","items":[1,2,3]}')
log(data.name, #data.items)
```

---

## Storage

Persistent key-value storage backed by JSON files on disk. Values survive
script restarts and server reboots.

### `storage` (per-slot)

Each script slot has its own storage file.

```lua
storage.set("last_run", datetime.iso())
storage.set("config", { worlds = {"A", "B"}, count = 5 })

local cfg = storage.get("config")
log(cfg.worlds[1])  -- "A"
```

### `globalStorage` (shared)

Shared across all script slots.

```lua
globalStorage.set("total_drops", 42)
local total = globalStorage.get("total_drops")
```

### Methods (same for both)

| Method               | Description                                |
|----------------------|--------------------------------------------|
| `get(key)`           | Returns the value, or `nil`                |
| `set(key, value)`    | Stores a value (auto-flushed to disk)      |
| `delete(key)`        | Removes a key; returns `true` if existed   |
| `keys()`             | Returns array of all key strings           |
| `clear()`            | Removes all keys                           |

---

## DateTime

The `datetime` module provides date/time utilities.

| Function                   | Returns                               |
|----------------------------|---------------------------------------|
| `datetime.unixSeconds()`   | Current time as Unix seconds (i64)    |
| `datetime.unixMillis()`    | Current time as Unix milliseconds     |
| `datetime.iso()`           | ISO 8601 / RFC 3339 string (UTC)      |
| `datetime.format([fmt])`   | UTC time with custom strftime format  |
| `datetime.formatLocal([fmt])` | Local time with custom strftime format |
| `datetime.monotonicMillis()` | Monotonic milliseconds (same as `now_ms`) |

```lua
log("time:", datetime.iso())
log("unix:", datetime.unixSeconds())
log("local:", datetime.formatLocal("%Y-%m-%d %H:%M:%S"))
```

Default format for `format()` / `formatLocal()` is `"%Y-%m-%dT%H:%M:%SZ"`.

---

## Random

The `random` module provides random number generation.

### `random.integer(min, max)`

Returns a random integer in `[min, max]` (inclusive).

```lua
local roll = random.integer(1, 6)
```

### `random.number([max])` / `random.number(min, max)`

Returns a random float. No args: `[0, 1)`. One arg: `[0, max)`. Two args:
`[min, max)`.

```lua
local f = random.number()        -- 0.0 to 1.0
local g = random.number(100)     -- 0.0 to 100.0
local h = random.number(5, 10)   -- 5.0 to 10.0
```

### `random.choice(table)`

Returns a random element from an array table, or `nil` if empty.

```lua
local msg = random.choice({"hello", "hi", "hey"})
```

### `random.shuffle(table)`

Shuffles an array table in-place (Fisher-Yates). Returns the same table.

```lua
local list = {1, 2, 3, 4, 5}
random.shuffle(list)
```

---

## Crypto

The `crypto` module provides hashing and encoding utilities.

| Function                       | Description                         |
|--------------------------------|-------------------------------------|
| `crypto.sha256(input)`         | SHA-256 hash as hex string          |
| `crypto.sha512(input)`         | SHA-512 hash as hex string          |
| `crypto.hexEncode(input)`      | Encode bytes to hex string          |
| `crypto.hexDecode(hex)`        | Decode hex string to bytes          |
| `crypto.base64Encode(input)`   | Standard Base64 encode              |
| `crypto.base64Decode(b64)`     | Standard Base64 decode              |
| `crypto.base64UrlEncode(input)`| URL-safe Base64 encode (no padding) |
| `crypto.base64UrlDecode(b64)`  | URL-safe Base64 decode              |

```lua
local hash = crypto.sha256("hello")
local encoded = crypto.base64Encode("secret data")
local decoded = crypto.base64Decode(encoded)
```

---

## UUID

### `uuid.new([format])`

Generates a new UUID v4. Optional format: `"simple"` (no dashes), `"urn"`
(with `urn:uuid:` prefix). Default format includes dashes.

```lua
local id = uuid.new()                -- "550e8400-e29b-41d4-a716-446655440000"
local simple = uuid.new("simple")    -- "550e8400e29b41d4a716446655440000"
local urn = uuid.new("urn")          -- "urn:uuid:550e8400-..."
```

---

## Regex

The `regex` module provides regular expression operations (Rust `regex` crate
syntax).

### `regex.isMatch(pattern, haystack)`

Returns `true` if the pattern matches anywhere in the string.

```lua
if regex.isMatch("\\d+", "abc123") then log("has numbers") end
```

### `regex.find(pattern, haystack)`

Returns the first match as a table, or `nil`.

```lua
local m = regex.find("(\\w+)@(\\w+)", "user@host")
if m then log(m.match, m.start, m["end"]) end
```

Fields: `match` (matched text), `start` (1-based position), `end` (end
position).

### `regex.findAll(pattern, haystack)`

Returns an array of all matches.

```lua
local matches = regex.findAll("\\d+", "a1b22c333")
for _, m in ipairs(matches) do log(m.match) end  -- "1", "22", "333"
```

### `regex.replace(pattern, haystack, replacement)`

Replaces all matches with the replacement string.

```lua
local result = regex.replace("\\s+", "hello   world", " ")
log(result)  -- "hello world"
```

### `regex.split(pattern, haystack)`

Splits the string by the pattern. Returns an array.

```lua
local parts = regex.split("[,;]", "a,b;c,d")
-- parts = {"a", "b", "c", "d"}
```

### `regex.escape(str)`

Escapes special regex characters in a string so it can be used as a literal
pattern.

```lua
local safe = regex.escape("hello.world")  -- "hello\\.world"
```

---

## HTTP / WebSocket API

The Mirai backend exposes HTTP and WebSocket endpoints for controlling the
Lua executor externally:

- `POST /api/lua/run` — body `{ "source": "<lua>" }`. Cancels any running
  script and starts a new one.
- `POST /api/lua/stop` — cancels the active script.
- `GET /ws/lua` (WebSocket) — pushes `LuaEvent` JSON frames:
  - `{ "type": "snapshot", "status": { ... } }` — sent once on connect
  - `{ "type": "line", "line": "..." }` — each `log(...)` call
  - `{ "type": "state", "running": bool, "state": "...", ... }` — state
    transitions
  - `{ "type": "cleared" }` — output cleared

  `state` values: `idle`, `running`, `stopping`, `stopped`, `finished`,
  `error`.
