# Mirai Lua Scripting

The Mirai Executor lets you automate your bots with Lua. One script runs at a
time and can drive any number of bots — you reach each one by name through the
`getBot` global, or create new ones with `addDevice` / `addClient`.

## Quick Start

```lua
local b = getBot("alpha")
if b == nil then
  log("alpha is not running")
  return
end

b:say("hello world")
log("alpha is at", b:pos().tile_x, b:pos().tile_y)
```

Press **Run** in the Executor panel to start, **Stop** to cancel. Anything you
pass to `log(...)` shows up in the Console panel below.

## Globals

### `addDevice([device_id])`

Creates a new bot with a random (or specified) device ID and returns a handle.

```lua
local bot = addDevice()
bot:connect()
```

### `addClient(email, password)`

Creates a new bot with email/password credentials and returns a handle.

```lua
local bot = addClient("user@example.com", "pass123")
bot:connect()
```

### `getBot(name)`

Returns a bot handle, or `nil` if no bot with that id exists.

```lua
local b = getBot("alpha")
```

### `getBots()`

Returns an array of all active bot id strings.

```lua
for _, id in ipairs(getBots()) do
  log("bot:", id)
end
```

### `getClients()`

Returns an array of bot handles (not just ids — actual handles).

```lua
for _, b in ipairs(getClients()) do
  log(b:name(), b:state())
end
```

### `removeClient(id)`

Removes a bot by id. Returns `true` if the bot existed.

### `log(...)` / `print(...)`

Writes a line to the Console. Multiple arguments are joined with a single
space. `print` is an alias for `log`.

```lua
log("started")
log("pos:", b:pos().tile_x, b:pos().tile_y)
```

### `sleep(ms)` / `sleep_ms(ms)`

Pauses the script for `ms` milliseconds. Inside a coroutine (`runThread` /
`task.spawn`), this yields instead of blocking the entire script.

```lua
sleep(5000)
```

### `now_ms()`

Returns the current time in milliseconds (monotonic clock).

```lua
local deadline = now_ms() + 30000
while now_ms() < deadline do sleep(1000) end
```

### `getItemInfo(id)` / `getItemInfos()`

Look up items from the block database. `getItemInfo` returns a single item
table (or `nil`), `getItemInfos` returns all items keyed by id.

```lua
local info = getItemInfo(242)
log(info.name, "tradeable:", info.is_tradeable)
```

## Bot Handle

`getBot(name)` / `addDevice()` / `addClient()` return a handle. Call methods
with the colon syntax (`b:method(args)`). Each call re-resolves the bot, so
handles survive bot disconnections gracefully.

### `b:name()`

Returns the bot id this handle points at.

### `b:pos()` / `b:position()`

Returns the bot's current position.

```lua
local p = b:pos()
log(p.x, p.y, p.tile_x, p.tile_y)
```

Fields: `x`, `y` (world position), `tile_x`, `tile_y` (map tile),
`direction`, `animation`.

### `b:state()`

Returns the current state as a string: `"Created"`, `"Disconnected"`,
`"Connecting"`, `"MenuIdle"`, `"LoadingWorld"`, `"SpawnSetup"`, `"InWorld"`,
`"Failed"`, `"Dead"`.

### `b:connected()`

Returns `true` if the bot is online (`InWorld` or `MenuIdle`).

### `b:connect()` / `b:disconnect()`

Connect or disconnect the bot.

### `b:get_world()`

Returns a snapshot of the world the bot is currently in.

```lua
local w = b:get_world()
log(w.name, w.width .. "x" .. w.height)

local p = b:pos()
log("standing on fg=" .. w:fg_at(p.tile_x, p.tile_y))
```

Top-level fields: `name`, `width`, `height`, `start`, `fg`/`foreground`,
`bg`/`background`, `water`, `wiring`, `seeds`.

Helpers: `w:index(x,y)`, `w:fg_at(x,y)`, `w:bg_at(x,y)`, `w:seed_at(x,y)`,
`w.tile_item_at(x,y)`, `w.size()`, `w.entrance()`.

### `b:walk(dx, dy)`

Moves the bot by a joystick-style offset (`dx`, `dy` clamped to `-1..1`).

```lua
b:walk(1, 0)    -- right
b:walk(0, -1)   -- up
b:walk(0, 0)    -- stop
```

### `b:say(message)`

Sends a world chat message. Add your own delay between sends to avoid the
server's spam limit.

### `b:place_block(dx, dy, item_id)` / `b:place(x, y, item_id)`

`place_block` uses tile offsets relative to the bot. `place` uses absolute
tile coordinates. The y axis grows downward.

```lua
b:place_block(1, 0, 7)    -- place to the right of the bot
b:place(42, 30, 7)        -- place at absolute tile
```

### `b:place_seed(dx, dy, item_id)` / `b:plant(x, y, item_id)`

Same offset vs absolute distinction. Plants a seed/sapling.

### `b:hit_block(dx, dy)` / `b:hit_block_at(x, y)` / `b:hit(x, y)`

Break blocks. `hit_block` uses offsets, `hit_block_at` and `hit` use absolute
coordinates.

### `b:warp(world [, special])`

Warps the bot into `world`. Supports portal targeting with `world:portalId`.

```lua
b:warp("PIXELSTATION")
b:warp("Rohumets:Byte67")   -- spawn at portal "Byte67"
```

### `b:enter_portal(portal_id)`

Enters a portal in the current world by its `entryPointID`.

### `b:leave()` / `b:respawn()`

Leave the world or respawn at spawn point.

### `b:find_path(tile_x, tile_y)` / `b:walkTo(x, y)`

Plans a path and **blocks until the bot arrives** (15s timeout). Uses absolute
map tile coordinates.

```lua
b:find_path(42, 30)
log("arrived")
```

### `b:start_path(x, y)`

Starts pathfinding **without blocking**. Useful for moving multiple bots in
parallel.

### `b:equip(item_id)` / `b:unequip(item_id)`

Equip or unequip an item.

### `b:drop(item_id, amount [, inventory_type])`

Drops items from inventory.

```lua
b:drop(7, 10)         -- drop 10 of item id 7
```

### `b:inventory()`

Returns `{ size, used, free, items }` where `items` is an array of
`{ item_id, inventory_type, amount }`.

### `b:get_inventory()`

Returns a detailed inventory array with `{ id, amount, inventory_type, flags, name }`.

### `b:has_item(block_id [, min])`

Returns `true` if inventory has at least `min` (default 1) of the item.

### `b:get_account()`

Returns `{ gems, level, xp, xp_to_next_level, inventory_slots }` or `nil`.

### `b:open_shop()` / `b:close_shop()` / `b:buy_pack(pack_id)`

Shop operations.

```lua
b:open_shop()
sleep(2000)
b:buy_pack("WorldLock")
sleep(2000)
b:close_shop()
```

### `b:start_tutorial()`

Starts the tutorial. Listen for `events.TUTORIAL_COMPLETED`.

### `b:select_block(item_id)` / `b:start_pnb(item_id, offsets)` / `b:stop_pnb()`

Block selection and place-and-break cycle.

### `b:get_players()`

Returns an array of other players: `{ user_id, username, x, y, tile_x, tile_y, direction, animation }`.

### `b:get_collectables()` / `b:collect(id)` / `b:collectAll()`

Get dropped items in world, collect one, or collect all (returns count).

### `b:get_tile(x, y)` / `b:get_tile_item(x, y)`

Tile data at absolute position. `get_tile` returns `{ x, y, fg, bg, water, wiring }`.
`get_tile_item` returns item data (portals, signs, etc.).

### `b:world_size()` / `b:entrance()`

Returns `Vec2i` userdata (or `nil`).

### `b:isWalkable(x, y)` / `b:findTiles(block_type)` / `b:seeds()`

Tile queries and seed data.

### `b:send_packet(packet)` / `b:get_world_name()` / `b:get_ping()`

Raw packet send, world name, and ping.

## Events

```lua
local b = getBot("alpha")
b:on(events.PACKET_RECEIVED, function(packet)
  log(packet.ids[1] or "?", packet.seq)
end)

while true do sleep(1000) end
```

Listeners only fire while the script is running.

### Event Names

| Constant                      | Payload                                |
|-------------------------------|----------------------------------------|
| `events.PACKET_RECEIVED`      | `{ seq, at, direction, ids, document }`|
| `events.CHAT_MESSAGE`         | `{ channel, user_id, username, message }` |
| `events.STATE_CHANGED`        | `{ state }`                            |
| `events.JOINED_WORLD`         | `{ world }`                            |
| `events.ERROR`                | `{ message }`                          |
| `events.TUTORIAL_COMPLETED`   | `{ completed = true }`                 |
| `events.PACK_PURCHASED`       | `{ pack_id, status, rewards }`         |

### `b:on(event, callback)` / `b:once(event, callback)` / `b:off(event)`

Subscribe, one-shot subscribe, or unsubscribe.

## Cooperative Threading

Run multiple tasks concurrently within one script using coroutines.

### `runThread(func)` / `task.spawn(func)`

Starts a cooperative coroutine. Inside the function, `sleep()` yields instead
of blocking. Returns a thread id.

```lua
-- Run 10 bots in parallel
for i = 1, 10 do
  runThread(function()
    local b = addDevice()
    b:connect()
    sleep(5000)
    b:warp("MYWORLD")
  end)
end

while true do sleep(1000) end
```

### `removeThread(id)` / `task.cancel(id)`

Stop a cooperative thread.

### `task.wait(seconds)`

Blocking wait (does NOT yield). For short pauses outside coroutines.

## HTTP Client

Make HTTP requests from scripts.

```lua
-- GET request
local resp = http.get("https://api.example.com/data")
if resp.ok then
  local data = json.decode(resp.body)
  log("result:", data.name)
end

-- POST with JSON
local resp = http.post("https://hooks.example.com/webhook", {
  json = { content = "Hello from Mirai!" },
  headers = { ["Authorization"] = "Bearer token" },
  timeout = 10000,
})
```

Methods: `http.get`, `http.post`, `http.put`, `http.delete`, `http.patch`.

Options: `headers` (table), `body` (string), `json` (auto-serialized),
`timeout` (ms, default 30000).

Response: `{ status, ok, body, headers }`.

## JSON

```lua
local s = json.encode({ name = "test", count = 42 })
local data = json.decode('{"key": "value"}')
```

## Storage

Persistent key-value storage (survives restarts).

```lua
-- Per-slot storage
storage.set("config", { worlds = {"A", "B"} })
local cfg = storage.get("config")

-- Shared across all slots
globalStorage.set("total", 100)
```

Methods: `get(key)`, `set(key, value)`, `delete(key)`, `keys()`, `clear()`.

## Vector Types

```lua
local v = Vector2.new(1.5, 2.0)    -- float vector
local vi = Vector2i.new(42, 30)    -- integer vector

-- Arithmetic: +, -, *, ==
local sum = vi + Vector2i.new(1, 0)
```

## Utility Modules

### DateTime

```lua
datetime.unixSeconds()        -- Unix timestamp
datetime.unixMillis()         -- Unix ms
datetime.iso()                -- "2026-05-07T12:34:56.789Z"
datetime.format("%H:%M")      -- UTC formatted
datetime.formatLocal("%H:%M") -- local time formatted
datetime.monotonicMillis()    -- same as now_ms()
```

### Random

```lua
random.integer(1, 100)           -- random int in [1, 100]
random.number()                  -- float in [0, 1)
random.number(10, 20)            -- float in [10, 20)
random.choice({"a", "b", "c"})   -- random element
random.shuffle({1, 2, 3, 4, 5})  -- shuffle in-place
```

### Crypto

```lua
crypto.sha256("hello")            -- hex hash
crypto.sha512("hello")
crypto.base64Encode("data")       -- standard base64
crypto.base64Decode("ZGF0YQ==")
crypto.base64UrlEncode("data")    -- URL-safe (no padding)
crypto.base64UrlDecode("ZGF0YQ")
crypto.hexEncode("data")          -- hex encoding
crypto.hexDecode("64617461")
```

### UUID

```lua
uuid.new()           -- "550e8400-e29b-41d4-..."
uuid.new("simple")   -- "550e8400e29b41d4..."
uuid.new("urn")      -- "urn:uuid:550e8400-..."
```

### Regex

```lua
regex.isMatch("\\d+", "abc123")         -- true
regex.find("\\w+", "hello world")       -- { match="hello", start=1, ["end"]=5 }
regex.findAll("\\d+", "a1b22c333")      -- array of matches
regex.replace("\\s+", "a  b  c", " ")   -- "a b c"
regex.split("[,;]", "a,b;c")            -- {"a", "b", "c"}
regex.escape("a.b")                     -- "a\\.b"
```

## Examples

### Create a bot and buy a World Lock

```lua
local bot = addDevice()
bot:connect()

-- Wait for menu
local start = now_ms()
while bot:state() ~= "MenuIdle" and now_ms() - start < 30000 do
  sleep(1000)
end

-- Complete tutorial
bot:once(events.TUTORIAL_COMPLETED, function() end)
bot:start_tutorial()
sleep(90000)

-- Buy World Lock
bot:open_shop()
sleep(2000)
bot:buy_pack("WorldLock")
sleep(2000)
bot:close_shop()
```

### Multi-bot farm with coroutines

```lua
local WORLDS = {"FARM1", "FARM2", "FARM3"}

for i, world in ipairs(WORLDS) do
  runThread(function()
    local b = addDevice()
    b:connect()
    sleep(random.integer(3000, 8000))

    while b:state() ~= "MenuIdle" do sleep(1000) end
    b:warp(world)
    sleep(3000)

    while true do
      b:collectAll()
      sleep(random.integer(5000, 10000))
    end
  end)
end

while true do sleep(1000) end
```

### Discord webhook notification

```lua
local function notify(message)
  http.post("https://discord.com/api/webhooks/YOUR_WEBHOOK", {
    json = { content = message }
  })
end

local b = getBot("alpha")
b:on(events.JOINED_WORLD, function(data)
  notify("Bot entered: " .. data.world)
end)

while true do sleep(1000) end
```

### Watch chat and auto-respond

```lua
local b = getBot("alpha")
b:on(events.CHAT_MESSAGE, function(msg)
  log("[" .. msg.channel .. "] " .. msg.username .. ": " .. msg.message)
  if msg.message == "!ping" then
    b:say("pong! " .. b:get_ping() .. "ms")
  end
end)

while true do sleep(1000) end
```

### Persistent state across restarts

```lua
local count = storage.get("run_count") or 0
count = count + 1
storage.set("run_count", count)
log("this script has been run", count, "times")
```
