import requests

# Step 1: PlayFab login
print("Step 1: PlayFab login...")
r = requests.post(
    "https://11ef5c.playfabapi.com/Client/LoginWithAndroidDeviceID",
    json={"AndroidDeviceId": "vpntest_final_001", "CreateAccount": True, "TitleId": "11EF5C"},
    timeout=15,
)
print(f"  Status: {r.status_code}")
if r.status_code != 200:
    print(f"  Error: {r.text[:200]}")
    exit()

data = r.json()["data"]
ticket = data["SessionTicket"]
pfid = data["PlayFabId"]
print(f"  PFID: {pfid}")
print(f"  Ticket: {ticket[:40]}...")

# Step 2: SocialFirst exchange
print("\nStep 2: SocialFirst exchange...")
r2 = requests.post(
    "https://pw-auth.pw.sclfrst.com/v1/auth/exchangeToken",
    json={"playfabToken": ticket},
    headers={
        "Content-Type": "application/json",
        "X-Sf-Client-Api-Key": "QwvzCrL2CexvXs2798fetBjty",
        "X-Unity-Version": "6000.3.11f1",
    },
    timeout=15,
)
print(f"  Status: {r2.status_code}")
print(f"  Body: {r2.text[:300]}")
