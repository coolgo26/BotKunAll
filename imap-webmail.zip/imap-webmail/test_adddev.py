import requests

print("1. PlayFab LoginWithAndroidDeviceID...")
r = requests.post(
    "https://11ef5c.playfabapi.com/Client/LoginWithAndroidDeviceID",
    json={"AndroidDeviceId": "adddev_test_002", "CreateAccount": True, "TitleId": "11EF5C"},
    timeout=15,
)
print(f"   Status: {r.status_code}")
if r.status_code != 200:
    print(f"   Error: {r.text[:200]}")
    exit()

d = r.json()["data"]
ticket = d["SessionTicket"]
pfid = d["PlayFabId"]
print(f"   PFID: {pfid}")
print(f"   NewlyCreated: {d.get('NewlyCreated')}")

print("\n2. SocialFirst exchangeToken...")
r2 = requests.post(
    "https://pw-auth.pw.sclfrst.com/v1/auth/exchangeToken",
    json={"playfabToken": ticket},
    headers={
        "Content-Type": "application/json",
        "X-Sf-Client-Api-Key": "QwvzCrL2CexvXs2798fetBjty",
        "X-Unity-Version": "6000.3.11f1",
    },
    timeout=15,
)
print(f"   Status: {r2.status_code}")
print(f"   Body: {r2.text[:300]}")

if r2.status_code == 200:
    jwt = r2.json().get("socialFirstToken", "")
    print(f"\n   JWT: {jwt[:50]}...")
    print("\n✅ addDevice flow SUCCESS!")
else:
    print("\n❌ SocialFirst FAILED")
